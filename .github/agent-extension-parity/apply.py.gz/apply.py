from pathlib import Path

def replace_once(path: str, old: str, new: str) -> None:
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    if new in text:
        print(f"{path}: replacement already applied")
        return
    if old not in text:
        raise SystemExit(f"{path}: expected block not found")
    p.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"{path}: updated")

# 1) Persist cached repository/catalog JSON for offline restore.
cache_path = Path("app/src/main/java/vn/nghetruyen/app/sourceplatform/VBookRepositoryCacheStore.kt")
cache_path.write_text(r'''package vn.nghetruyen.app.sourceplatform

import android.content.Context
import java.io.File
import java.security.MessageDigest

data class VBookCachedRepositoryDocument(
    val body: String,
    val updatedAtEpochMs: Long,
)

/**
 * Small bounded on-disk cache for vBook repository index/catalog JSON.
 *
 * This cache never stores install ZIPs and is only used to rebuild repository listings when the
 * network is unavailable. Package installation still goes through the normal download/verify path.
 */
class VBookRepositoryCacheStore(context: Context) {
    private val directory = File(context.applicationContext.filesDir, DIRECTORY).apply { mkdirs() }

    @Synchronized
    fun read(url: String, maxBytes: Int): VBookCachedRepositoryDocument? {
        if (maxBytes <= 0) return null
        val file = fileFor(url)
        if (!file.isFile || file.length() <= 0L || file.length() > maxBytes.toLong()) return null
        return runCatching {
            VBookCachedRepositoryDocument(
                body = file.readText(Charsets.UTF_8),
                updatedAtEpochMs = file.lastModified().coerceAtLeast(0L),
            )
        }.getOrNull()
    }

    @Synchronized
    fun write(url: String, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        if (bytes.isEmpty() || bytes.size > MAX_ENTRY_BYTES) return
        val first = body.firstOrNull { !it.isWhitespace() }
        if (first != '{' && first != '[') return

        directory.mkdirs()
        val target = fileFor(url)
        val temp = File(directory, "${target.name}.tmp-${System.nanoTime()}")
        runCatching {
            temp.writeBytes(bytes)
            if (!temp.renameTo(target)) {
                target.writeBytes(bytes)
                temp.delete()
            }
            target.setLastModified(System.currentTimeMillis())
            prune()
        }.onFailure {
            temp.delete()
        }
    }

    @Synchronized
    fun remove(url: String) {
        runCatching { fileFor(url).delete() }
    }

    private fun prune() {
        val files = directory.listFiles()
            .orEmpty()
            .filter { it.isFile && !it.name.contains(".tmp-") }
            .sortedByDescending(File::lastModified)

        var total = 0L
        files.forEachIndexed { index, file ->
            total += file.length().coerceAtLeast(0L)
            if (index >= MAX_ENTRIES || total > MAX_TOTAL_BYTES) {
                runCatching { file.delete() }
            }
        }
    }

    private fun fileFor(url: String): File {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(url.trim().toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
        return File(directory, "$digest.json")
    }

    companion object {
        private const val DIRECTORY = "vbook_repository_catalog_cache_v1"
        private const val MAX_ENTRY_BYTES = 16 * 1024 * 1024
        private const val MAX_TOTAL_BYTES = 32L * 1024L * 1024L
        private const val MAX_ENTRIES = 256
    }
}
''', encoding="utf-8")

replace_once(
    "app/src/main/java/vn/nghetruyen/app/AppContainer.kt",
    '''import vn.nghetruyen.app.sourceplatform.VBookRepositoryClient
import vn.nghetruyen.app.sourceplatform.VBookRepositorySubscriptionStore
''',
    '''import vn.nghetruyen.app.sourceplatform.VBookRepositoryCacheStore
import vn.nghetruyen.app.sourceplatform.VBookRepositoryClient
import vn.nghetruyen.app.sourceplatform.VBookRepositorySubscriptionStore
''',
)

replace_once(
    "app/src/main/java/vn/nghetruyen/app/AppContainer.kt",
    '''    val vBookRepositoryClient: VBookRepositoryClient by lazy {
        VBookRepositoryClient(diagnostics = sourceDiagnostics.recorder, evidence = sourceDiagnostics.evidence)
    }

    val vBookRepositorySubscriptionStore: VBookRepositorySubscriptionStore by lazy {
''',
    '''    val vBookRepositoryCacheStore: VBookRepositoryCacheStore by lazy {
        VBookRepositoryCacheStore(appContext)
    }

    val vBookRepositoryClient: VBookRepositoryClient by lazy {
        VBookRepositoryClient(
            cache = vBookRepositoryCacheStore,
            diagnostics = sourceDiagnostics.recorder,
            evidence = sourceDiagnostics.evidence,
        )
    }

    val vBookRepositorySubscriptionStore: VBookRepositorySubscriptionStore by lazy {
''',
)

replace_once(
    "app/src/main/java/vn/nghetruyen/app/sourceplatform/VBookRepositoryClient.kt",
    '''class VBookRepositoryClient(
    network: OkHttpSourceNetworkBroker? = null,
    private val diagnostics: DiagnosticSink = DiagnosticSink.NONE,
    private val evidence: DiagnosticEvidenceSink = DiagnosticEvidenceSink.NONE,
) {
''',
    '''class VBookRepositoryClient(
    network: OkHttpSourceNetworkBroker? = null,
    private val cache: VBookRepositoryCacheStore? = null,
    private val diagnostics: DiagnosticSink = DiagnosticSink.NONE,
    private val evidence: DiagnosticEvidenceSink = DiagnosticEvidenceSink.NONE,
) {
''',
)

replace_once(
    "app/src/main/java/vn/nghetruyen/app/sourceplatform/VBookRepositoryClient.kt",
    '''    private val fetcher = VBookRepositoryFetcher { url, maxBytes ->
        val bytes = fetchBytes(url, maxBytes)
        VBookRepositoryFetchResult(url, bytes.toString(Charsets.UTF_8), sha256(bytes))
    }
''',
    '''    private val fetcher = VBookRepositoryFetcher { url, maxBytes ->
        runCatching {
            val bytes = fetchBytes(url, maxBytes)
            val body = bytes.toString(Charsets.UTF_8)
            cache?.write(url, body)
            VBookRepositoryFetchResult(url, body, sha256(bytes))
        }.getOrElse { networkError ->
            val cached = cache?.read(url, maxBytes) ?: throw networkError
            val bytes = cached.body.toByteArray(Charsets.UTF_8)
            val traceId = traceContext.get().orEmpty().ifBlank { "repository-cache:${UUID.randomUUID()}" }
            emit(
                traceId,
                "VBOOK_REPOSITORY_CACHE_FALLBACK",
                DiagnosticSeverity.WARNING,
                mapOf(
                    "url" to url,
                    "ageMs" to (System.currentTimeMillis() - cached.updatedAtEpochMs).coerceAtLeast(0L).toString(),
                    "networkError" to (networkError.message ?: networkError.javaClass.simpleName).take(500),
                ),
            )
            VBookRepositoryFetchResult(url, cached.body, sha256(bytes))
        }
    }
''',
)

replace_once(
    "app/src/main/java/vn/nghetruyen/app/sourceplatform/VBookRepositoryClient.kt",
    '''    fun downloadPackage(item: VBookAggregatedItem): ByteArray = withTrace("package") { traceId ->
''',
    '''    fun evictCachedDocument(url: String) {
        cache?.remove(url)
    }

    fun downloadPackage(item: VBookAggregatedItem): ByteArray = withTrace("package") { traceId ->
''',
)

replace_once(
    "app/src/main/java/vn/nghetruyen/app/sourceplatform/UnifiedSourcePlatformManager.kt",
    '''        if (persistedUrl != null) {
            return runCatching { vBookRepositorySubscriptions.remove(persistedUrl) }
        }
''',
    '''        if (persistedUrl != null) {
            return runCatching {
                vBookRepositories.evictCachedDocument(persistedUrl)
                vBookRepositorySubscriptions.remove(persistedUrl)
            }
        }
''',
)

# 2) Upgrade extension search to Lua-like live SmartSearch.
replace_once(
    "app/src/main/java/vn/nghetruyen/app/ui/screens/PersonalScreen.kt",
    '''private fun extensionSearchScore(value: String, query: String): Int? {
    val tokens = extensionSearchNormalize(query).split(' ').filter(String::isNotBlank)
    if (tokens.isEmpty()) return 0
    val searchable = extensionSearchNormalize(value)
    var score = 0
    tokens.forEach { token ->
        val index = searchable.indexOf(token)
        if (index < 0) return null
        score += index
    }
    return score
}

''',
    '''private fun extensionSearchScore(value: String, query: String): Int? {
    val normalizedQuery = extensionSearchNormalize(query)
    if (normalizedQuery.isBlank()) return 0

    val searchable = extensionSearchNormalize(value)
    if (searchable.isBlank()) return null
    val words = searchable.split(' ').filter(String::isNotBlank)
    val compact = words.joinToString("")
    val acronym = words.mapNotNull { it.firstOrNull()?.toString() }.joinToString("")
    val tokens = normalizedQuery.split(' ').filter(String::isNotBlank)

    var score = 0
    tokens.forEach { token ->
        val tokenScore = extensionTokenSearchScore(token, searchable, words, compact, acronym) ?: return null
        score += tokenScore
    }

    val phraseIndex = searchable.indexOf(normalizedQuery)
    if (phraseIndex >= 0) {
        score -= minOf(40, 20 + normalizedQuery.length)
    }
    return score.coerceAtLeast(0)
}

private fun extensionTokenSearchScore(
    token: String,
    searchable: String,
    words: List<String>,
    compact: String,
    acronym: String,
): Int? {
    val exactWord = words.indexOf(token)
    if (exactWord >= 0) return exactWord

    val prefixWord = words.indexOfFirst { it.startsWith(token) }
    if (prefixWord >= 0) return 10 + prefixWord

    val substring = searchable.indexOf(token)
    if (substring >= 0) return 20 + substring

    if (token.length >= 2) {
        if (acronym.startsWith(token)) return 40 + (acronym.length - token.length)
        extensionSubsequenceScore(token, acronym)?.let { return 50 + it }
    }

    if (token.length >= 3) {
        extensionSubsequenceScore(token, compact)?.let { gaps ->
            if (gaps <= token.length * 2 + 8) return 70 + gaps
        }
    }

    val editLimit = when {
        token.length >= 7 -> 2
        token.length >= 4 -> 1
        else -> 0
    }
    if (editLimit > 0) {
        var bestDistance: Int? = null
        words.forEach { word ->
            if (kotlin.math.abs(word.length - token.length) <= editLimit) {
                extensionEditDistance(token, word, editLimit)?.let { distance ->
                    bestDistance = minOf(bestDistance ?: distance, distance)
                }
            }
        }
        bestDistance?.let { return 100 + it * 10 }
    }

    return null
}

private fun extensionSubsequenceScore(needle: String, haystack: String): Int? {
    if (needle.isEmpty()) return 0
    var needleIndex = 0
    var firstMatch = -1
    var lastMatch = -1
    haystack.forEachIndexed { index, char ->
        if (needleIndex < needle.length && char == needle[needleIndex]) {
            if (firstMatch < 0) firstMatch = index
            lastMatch = index
            needleIndex += 1
        }
    }
    if (needleIndex != needle.length) return null
    return (lastMatch - firstMatch + 1 - needle.length).coerceAtLeast(0) + firstMatch.coerceAtLeast(0)
}

private fun extensionEditDistance(left: String, right: String, limit: Int): Int? {
    if (kotlin.math.abs(left.length - right.length) > limit) return null
    var previous = IntArray(right.length + 1) { it }
    left.forEachIndexed { leftIndex, leftChar ->
        val current = IntArray(right.length + 1)
        current[0] = leftIndex + 1
        var rowMinimum = current[0]
        right.forEachIndexed { rightIndex, rightChar ->
            val insert = current[rightIndex] + 1
            val delete = previous[rightIndex + 1] + 1
            val replace = previous[rightIndex] + if (leftChar == rightChar) 0 else 1
            current[rightIndex + 1] = minOf(insert, delete, replace)
            rowMinimum = minOf(rowMinimum, current[rightIndex + 1])
        }
        if (rowMinimum > limit) return null
        previous = current
    }
    return previous[right.length].takeIf { it <= limit }
}

private fun extensionDiagnosticLabel(name: String, severity: String): String {
    val action = when {
        name.contains("INSTALL", ignoreCase = true) -> "Cài đặt tiện ích"
        name.contains("PACKAGE", ignoreCase = true) || name.contains("FETCH", ignoreCase = true) -> "Tải dữ liệu"
        name.contains("NETWORK", ignoreCase = true) || name.contains("HTTP", ignoreCase = true) -> "Kết nối mạng"
        name.contains("PARSE", ignoreCase = true) || name.contains("PARSER", ignoreCase = true) -> "Phân tích dữ liệu"
        name.contains("BROWSER", ignoreCase = true) || name.contains("WEBVIEW", ignoreCase = true) -> "Trình duyệt"
        name.contains("LOGIN", ignoreCase = true) || name.contains("SESSION", ignoreCase = true) -> "Phiên đăng nhập"
        name.contains("ACTION", ignoreCase = true) || name.contains("RUNTIME", ignoreCase = true) -> "Chạy tiện ích"
        else -> name.replace('_', ' ').lowercase(Locale.ROOT).replaceFirstChar { it.titlecase(Locale.ROOT) }
    }
    return when {
        severity.equals("ERROR", ignoreCase = true) || name.contains("FAILED", ignoreCase = true) -> "$action thất bại"
        name.contains("STARTED", ignoreCase = true) -> "Bắt đầu $action"
        name.contains("COMPLETED", ignoreCase = true) || name.contains("SUCCEEDED", ignoreCase = true) -> "$action hoàn tất"
        else -> action
    }
}

''',
)

# 3) Per-extension logs using the existing diagnostics backend.
replace_once(
    "app/src/main/java/vn/nghetruyen/app/ui/screens/PersonalScreen.kt",
    '''    var removePackId by remember { mutableStateOf<String?>(null) }
    var installedQuery by remember { mutableStateOf("") }
''',
    '''    var removePackId by remember { mutableStateOf<String?>(null) }
    var logPackId by remember { mutableStateOf<String?>(null) }
    var logTechnicalDetailsVisible by remember { mutableStateOf(false) }
    var installedQuery by remember { mutableStateOf("") }
''',
)

replace_once(
    "app/src/main/java/vn/nghetruyen/app/ui/screens/PersonalScreen.kt",
    '''                        ReferenceActionButton(
                            text = "KIỂM TRA NGUỒN",
                            onClick = {
                                onCheck(pack.id)
                                selectedPackId = null
                            },
                            normalColor = ReferencePanelBackground,
                            normalContentColor = ReferenceText,
                            modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                        )
                        ReferenceActionButton(
                            text = "CẬP NHẬT",
''',
    '''                        ReferenceActionButton(
                            text = "KIỂM TRA NGUỒN",
                            onClick = {
                                onCheck(pack.id)
                                selectedPackId = null
                            },
                            normalColor = ReferencePanelBackground,
                            normalContentColor = ReferenceText,
                            modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                        )
                        ReferenceActionButton(
                            text = "NHẬT KÝ",
                            onClick = {
                                logPackId = pack.id
                                logTechnicalDetailsVisible = false
                                selectedPackId = null
                            },
                            normalColor = ReferencePanelBackground,
                            normalContentColor = ReferenceText,
                            modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                        )
                        ReferenceActionButton(
                            text = "CẬP NHẬT",
''',
)

log_dialog = r'''    logPackId?.let { packId ->
        val pack = state.sourcePacks.firstOrNull { it.id == packId }
        if (pack != null) {
            val events = state.sourceDiagnostics.filter { it.sourceId == packId }.take(80)
            val traces = state.sourceTraces.filter { it.sourceId == packId }.take(30)
            AlertDialog(
                onDismissRequest = {
                    logPackId = null
                    logTechnicalDetailsVisible = false
                },
                title = { Text("NHẬT KÝ TIỆN ÍCH") },
                text = {
                    Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                        Text(pack.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${events.size} sự kiện gần nhất",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                        if (events.isEmpty()) {
                            Text(
                                "Chưa có nhật ký cho tiện ích này. Hãy dùng hoặc kiểm tra nguồn rồi mở lại nhật ký.",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        } else {
                            events.forEach { event ->
                                val timestamp = SimpleDateFormat(
                                    "HH:mm:ss dd/MM/yyyy",
                                    Locale.getDefault(),
                                ).format(Date(event.timestampEpochMs))
                                Text(
                                    "$timestamp • ${extensionDiagnosticLabel(event.name, event.severity)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = if (event.severity == "ERROR") FontWeight.SemiBold else FontWeight.Normal,
                                )
                                if (logTechnicalDetailsVisible) {
                                    val duration = event.durationMs?.let { " • ${it} ms" }.orEmpty()
                                    Text(
                                        "${event.category}/${event.name}$duration",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                    Text(
                                        "trace ${event.traceId.take(24)}${event.detail.takeIf(String::isNotBlank)?.let { " • $it" }.orEmpty()}",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                                HorizontalDivider(Modifier.padding(vertical = 5.dp))
                            }
                        }
                        if (logTechnicalDetailsVisible && traces.isNotEmpty()) {
                            Text("TRACE", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                            traces.forEach { trace ->
                                Text(
                                    "${if (trace.failed) "LỖI" else "OK"} • ${trace.eventCount} sự kiện • ${trace.endedAtEpochMs - trace.startedAtEpochMs} ms • ${trace.traceId.take(24)}",
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        logPackId = null
                        logTechnicalDetailsVisible = false
                    }) { Text("ĐÓNG") }
                },
                dismissButton = {
                    if (events.isNotEmpty()) {
                        TextButton(onClick = { logTechnicalDetailsVisible = !logTechnicalDetailsVisible }) {
                            Text(if (logTechnicalDetailsVisible) "ẨN CHI TIẾT" else "CHI TIẾT KỸ THUẬT")
                        }
                    }
                },
            )
        }
    }

'''
personal_path = Path("app/src/main/java/vn/nghetruyen/app/ui/screens/PersonalScreen.kt")
text = personal_path.read_text(encoding="utf-8")
marker = '    removePackId?.let { packId ->\n'
if log_dialog.strip() not in text:
    if marker not in text:
        raise SystemExit("PersonalScreen.kt: remove dialog marker not found")
    text = text.replace(marker, log_dialog + marker, 1)
    personal_path.write_text(text, encoding="utf-8")
    print("PersonalScreen.kt: per-extension log dialog added")
else:
    print("PersonalScreen.kt: log dialog already present")

print("Agent extension parity patch applied.")
