return {
  api_version = 2,
  metadata = {
    id = "truyencom-default-native",
    name = "Truyện Com",
    version = 3,
    author = "Nghe Truyện",
    website = "https://truyencom.com",
    description = "Nguồn Truyện Com đầy đủ cho R10.2+, dùng HTTP nền và phân trang động; bao gồm toàn bộ danh sách, thể loại và các tag nổi bật đang công khai trên website.",
    locale = "vi",
    type = "novel",
    updated = "2026-07-21"
  },
  source = {
    base_url = "https://truyencom.com",
    home_url = "https://truyencom.com/truyen-moi-cap-nhat/",
    allowed_hosts = {"truyencom.com", "www.truyencom.com", "dtruyen.com", "www.dtruyen.com"},
    permissions = {
      browser = false,
      hosts = {"truyencom.com", "www.truyencom.com", "dtruyen.com", "www.dtruyen.com"}
    },
    config = {
      timeout = {title = "Thời gian chờ", ["default"] = "30000", mode = "input", format = "number"}
    },
    pipelines = {
      normalize_stories = {
        steps = {
          {transform = {from = "$args.items", operations = {
            {op = "filter", as = "item", condition = {left = "$vars.item.url", op = "not_empty"}},
            {op = "filter", as = "item", condition = {left = "$vars.item.name", op = "not_empty"}},
            {op = "filter", as = "item", condition = {left = "$vars.item.url", op = "not_contains", right = "/chuong-"}},
            {op = "filter", as = "item", condition = {left = "$vars.item.url", op = "not_contains", right = "/the-loai/"}},
            {op = "filter", as = "item", condition = {left = "$vars.item.url", op = "not_contains", right = "/tac-gia/"}},
            {op = "filter", as = "item", condition = {left = "$vars.item.url", op = "not_contains", right = "/tag/"}},
            {op = "unique", by = "url"}
          }, into = "normalized"}}
        }
      },
      normalize_chapters = {
        steps = {
          {transform = {from = "$args.items", operations = {
            {op = "filter", as = "item", condition = {left = "$vars.item.url", op = "not_empty"}},
            {op = "filter", as = "item", condition = {left = "$vars.item.name", op = "contains", right = "Chương"}},
            {op = "unique", by = "url"}
          }, into = "normalized"}}
        }
      }
    },
    actions = {
      categories = {
        result = {
          type = "categories",
          items = {
            {name = "Mới cập nhật", url = "https://truyencom.com/truyen-moi-cap-nhat/"},
            {name = "Truyện mới đăng", url = "https://truyencom.com/truyen-moi-dang/"},
            {name = "Truyện Hot (BXH)", url = "https://truyencom.com/truyen-hot/"},
            {name = "Truyện Full", url = "https://truyencom.com/truyen-full/"},
            {name = "Tiên Hiệp", url = "https://truyencom.com/truyen-tien-hiep/full/"},
            {name = "Kiếm Hiệp", url = "https://truyencom.com/truyen-kiem-hiep/full/"},
            {name = "Ngôn Tình", url = "https://truyencom.com/truyen-ngon-tinh/full/"},
            {name = "Quan Trường", url = "https://truyencom.com/truyen-quan-truong/full/"},
            {name = "Xuyên Không", url = "https://truyencom.com/truyen-xuyen-khong/full/"},
            {name = "Trinh Thám", url = "https://truyencom.com/truyen-trinh-tham/full/"},
            {name = "Thám Hiểm", url = "https://truyencom.com/truyen-tham-hiem/full/"},
            {name = "Linh Dị", url = "https://truyencom.com/truyen-linh-di/full/"},
            {name = "Ngược", url = "https://truyencom.com/truyen-nguoc/full/"},
            {name = "Sủng", url = "https://truyencom.com/truyen-sung/full/"},
            {name = "Cung Đấu", url = "https://truyencom.com/truyen-cung-dau/full/"},
            {name = "Nữ Cường", url = "https://truyencom.com/truyen-nu-cuong/full/"},
            {name = "Đông Phương", url = "https://truyencom.com/truyen-dong-phuong/full/"},
            {name = "Đam Mỹ", url = "https://truyencom.com/truyen-dam-my/full/"},
            {name = "Bách Hợp", url = "https://truyencom.com/truyen-bach-hop/full/"},
            {name = "Hài Hước", url = "https://truyencom.com/truyen-hai-huoc/full/"},
            {name = "Cổ Đại", url = "https://truyencom.com/truyen-co-dai/full/"},
            {name = "Mạt Thế", url = "https://truyencom.com/truyen-mat-the/full/"},
            {name = "Tiểu Thuyết", url = "https://truyencom.com/truyen-tieu-thuyet/full/"},
            {name = "Khác", url = "https://truyencom.com/truyen-khac/full/"},
            {name = "Võng Du", url = "https://truyencom.com/truyen-vong-du/full/"},
            {name = "Khoa Huyễn", url = "https://truyencom.com/truyen-khoa-huyen/full/"},
            {name = "Dị Năng", url = "https://truyencom.com/truyen-di-nang/full/"},
            {name = "Huyền Huyễn", url = "https://truyencom.com/truyen-huyen-huyen/full/"},
            {name = "Trọng Sinh", url = "https://truyencom.com/truyen-trong-sinh/full/"},
            {name = "Đô Thị", url = "https://truyencom.com/truyen-do-thi/full/"},
            {name = "Dị Giới", url = "https://truyencom.com/truyen-di-gioi/full/"},
            {name = "Gia Đấu", url = "https://truyencom.com/truyen-gia-dau/full/"},
            {name = "Điền Văn", url = "https://truyencom.com/truyen-dien-van/full/"},
            {name = "Nữ Phụ", url = "https://truyencom.com/truyen-nu-phu/full/"},
            {name = "Quân Sự", url = "https://truyencom.com/truyen-quan-su/full/"},
            {name = "Lịch Sử", url = "https://truyencom.com/truyen-lich-su/full/"},
            {name = "Truyện Teen", url = "https://truyencom.com/truyen-teen/full/"},
            {name = "Light Novel", url = "https://truyencom.com/truyen-light-novel/full/"},
            {name = "Đoản Văn", url = "https://truyencom.com/truyen-doan-van/full/"},
            {name = "Việt Nam", url = "https://truyencom.com/truyen-viet-nam/full/"},
            {name = "Dã Sử", url = "https://truyencom.com/truyen-da-su/full/"},
            {name = "Phương Tây", url = "https://truyencom.com/truyen-phuong-tay/full/"},
            {name = "Hệ Thống", url = "https://truyencom.com/truyen-he-thong/full/"},
            {name = "Xuyên Nhanh", url = "https://truyencom.com/truyen-xuyen-nhanh/full/"},
            {name = "Hiện Đại", url = "https://truyencom.com/truyen-hien-dai/full/"},
            {name = "Tổng Tài", url = "https://truyencom.com/truyen-tong-tai/full/"},
            {name = "Ngôn Tình Xuyên Không", url = "https://truyencom.com/tag/ngon-tinh-xuyen-khong/"},
            {name = "Ngôn Tình Trọng Sinh", url = "https://truyencom.com/tag/ngon-tinh-trong-sinh/"},
            {name = "Ngôn Tình Nữ Cường", url = "https://truyencom.com/tag/ngon-tinh-nu-cuong/"},
            {name = "Ngôn Tình Cung Đấu", url = "https://truyencom.com/tag/ngon-tinh-cung-dau/"},
            {name = "Ngôn Tình Full", url = "https://truyencom.com/tag/ngon-tinh-full/"},
            {name = "Ngôn Tình Dị Năng", url = "https://truyencom.com/tag/ngon-tinh-di-nang/"},
          },
          fields = {name = "name", url = {path = "url", absolute = true}}
        }
      },
      latest = {
        steps = {
          {set = {target = {first = {{from = "$page"}, {value = "https://truyencom.com/truyen-moi-cap-nhat/"}}}}},
          {request = {id = "list", url = "{vars.target}", response = "html", timeout = "{config.timeout??30000}", retries = 1}},
          {set = {
            raw_items = {from = "$list", items = {selector = ".list-truyen .truyen-title a, .list-truyen h3 a, .list-truyen h2 a, h3.truyen-title a, .story-title a"}, fields = {
              name = {self = true}, url = {self = true, attr = "href", absolute = true}
            }},
            next_page = {from = "$list", selector = {".pagination li.active + li a", "a[rel=next]", ".pagination a.next", ".pagination .next a"}, attr = "href", absolute = true}
          }},
          {call_pipeline = {name = "normalize_stories", args = {items = "$vars.raw_items"}, into = "items"}}
        },
        result = {type = "items", from = "$vars.items", allow_empty = true, fields = {name = "name", url = {path = "url", absolute = true}}, next = {from = "$vars.next_page"}}
      },
      stories = {
        steps = {
          {set = {target = {first = {{from = "$page"}, {from = "$input"}, {value = "https://truyencom.com/truyen-moi-cap-nhat/"}}}}},
          {request = {id = "list", url = "{vars.target}", response = "html", timeout = "{config.timeout??30000}", retries = 1}},
          {set = {
            raw_items = {from = "$list", items = {selector = ".list-truyen .truyen-title a, .list-truyen h3 a, .list-truyen h2 a, h3.truyen-title a, .story-title a"}, fields = {
              name = {self = true}, url = {self = true, attr = "href", absolute = true}
            }},
            next_page = {from = "$list", selector = {".pagination li.active + li a", "a[rel=next]", ".pagination a.next", ".pagination .next a"}, attr = "href", absolute = true}
          }},
          {call_pipeline = {name = "normalize_stories", args = {items = "$vars.raw_items"}, into = "items"}}
        },
        result = {type = "items", from = "$vars.items", allow_empty = true, fields = {name = "name", url = {path = "url", absolute = true}}, next = {from = "$vars.next_page"}}
      },
      search = {
        steps = {
          {set = {target = {template = "https://truyencom.com/tim-kiem/?tukhoa={query|urlencode}"}}},
          {["when"] = {from = "$page"}, set = {target = {from = "$page"}}},
          {request = {id = "list", url = "{vars.target}", response = "html", timeout = "{config.timeout??30000}", retries = 1}},
          {set = {
            raw_items = {from = "$list", items = {selector = ".list-truyen .truyen-title a, .list-truyen h3 a, .list-truyen h2 a, h3.truyen-title a, .story-title a"}, fields = {
              name = {self = true}, url = {self = true, attr = "href", absolute = true}
            }},
            next_page = {from = "$list", selector = {".pagination li.active + li a", "a[rel=next]", ".pagination a.next"}, attr = "href", absolute = true}
          }},
          {call_pipeline = {name = "normalize_stories", args = {items = "$vars.raw_items"}, into = "items"}}
        },
        result = {type = "items", from = "$vars.items", allow_empty = true, fields = {name = "name", url = {path = "url", absolute = true}}, next = {from = "$vars.next_page"}}
      },
      detail = {
        request = {id = "detail", url = "{input}", response = "html", timeout = "{config.timeout??30000}", retries = 1},
        result = {type = "detail", from = "$detail", fields = {
          name = {selector = {"h3.title", "h1.title", "h1"}},
          author = {selector = {"a[href*='/tac-gia/']", ".info a[itemprop=author]"}},
          cover = {selector = {"meta[property=og:image]", ".book img", ".info-holder img"}, attr = "content", absolute = true},
          description = {selector = {".desc-text", ".description", ".desc"}, mode = "html"},
          ongoing = {selector = "body", matches = "Đang ra|Đang cập nhật"},
          genres = {items = {selector = {"a[href*='/the-loai/']", "a[href*='/truyen-'][href*='/full/']"}}, fields = {name = {self = true}, url = {self = true, attr = "href", absolute = true}}}
        }}
      },
      chapters = {
        steps = {
          {request = {id = "chapter_page", url = "{input}", response = "html", timeout = "{config.timeout??30000}", retries = 1}},
          {set = {
            raw_chapters = {from = "$chapter_page", items = {selector = ".list-chapter a[href*='/chuong-'], ul.list-chapter a[href*='/chuong-'], #list-chapter a[href*='/chuong-']"}, fields = {
              name = {self = true}, url = {self = true, attr = "href", absolute = true}
            }},
            next_page = {from = "$chapter_page", selector = {".pagination li.active + li a", "a[rel=next]", ".pagination a.next"}, attr = "href", absolute = true}
          }},
          {call_pipeline = {name = "normalize_chapters", args = {items = "$vars.raw_chapters"}, into = "items"}}
        },
        result = {type = "items", from = "$vars.items", allow_empty = true, fields = {name = "name", url = {path = "url", absolute = true}}, next = {from = "$vars.next_page"}}
      },
      content = {
        request = {id = "chapter", url = "{input}", response = "html", timeout = "{config.timeout??30000}", retries = 1},
        result = {type = "content", from = "$chapter", fields = {
          title = {selector = {".chapter-title", "h2", "h1"}},
          content = {selector = {"#chapter-c", ".chapter-c", "#chapter-content", ".chapter-content"}, mode = "html", remove = {"script", "style", "iframe", "noscript", ".ads", ".chapter-nav", ".navigation"}}
        }}
      }
    }
  }
}
