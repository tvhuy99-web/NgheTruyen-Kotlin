from pathlib import Path
import re

ROOT = Path('.')

def read(path):
    return (ROOT / path).read_text(encoding='utf-8')

def write(path, text):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')
    print('patched', path)

def replace_once(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise SystemExit(f'{label}: expected 1 exact match, found {n}')
    return text.replace(old, new, 1)

def regex_once(text, pattern, repl, label, flags=0):
    out, n = re.subn(pattern, repl, text, count=1, flags=flags)
    if n != 1:
        raise SystemExit(f'{label}: expected 1 regex match, found {n}')
    return out

# 1) Lightweight persistent Home snapshot cache. Network still refreshes after first frame.
home_cache = '''package vn.nghetruyen.app.ui

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import vn.nghetruyen.app.core.model.StorySummary

internal class ExploreHomeCache(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(sourceId: String, nowMs: Long = System.currentTimeMillis()): List<StorySummary> {
        val key = sourceId.trim().takeIf(String::isNotBlank) ?: return emptyList()
        val savedAt = prefs.getLong(savedAtKey(key), 0L)
        if (savedAt <= 0L || nowMs - savedAt > MAX_AGE_MILLIS) return emptyList()
        val raw = prefs.getString(itemsKey(key), null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList(minOf(array.length(), MAX_ITEMS)) {
                repeat(minOf(array.length(), MAX_ITEMS)) { index ->
                    val item = array.optJSONObject(index) ?: return@repeat
                    val id = item.optString("id").trim()
                    val itemSourceId = item.optString("sourceId").trim().ifBlank { key }
                    val title = item.optString("title").trim()
                    if (id.isBlank() || title.isBlank()) return@repeat
                    add(
                        StorySummary(
                            id = id,
                            sourceId = itemSourceId,
                            title = title,
                            author = item.optString("author"),
                            coverUrl = item.optString("coverUrl").takeIf(String::isNotBlank),
                            description = item.optString("description"),
                            url = item.optString("url"),
                        ),
                    )
                }
            }
        }.getOrElse { emptyList() }
    }

    fun save(sourceId: String, stories: List<StorySummary>, nowMs: Long = System.currentTimeMillis()) {
        val key = sourceId.trim().takeIf(String::isNotBlank) ?: return
        if (stories.isEmpty()) return
        val array = JSONArray()
        stories.take(MAX_ITEMS).forEach { story ->
            array.put(JSONObject().apply {
                put("id", story.id)
                put("sourceId", story.sourceId)
                put("title", story.title)
                put("author", story.author)
                put("coverUrl", story.coverUrl ?: "")
                put("description", story.description)
                put("url", story.url)
            })
        }
        prefs.edit()
            .putString(itemsKey(key), array.toString())
            .putLong(savedAtKey(key), nowMs)
            .apply()
    }

    fun clear(sourceId: String) {
        val key = sourceId.trim().takeIf(String::isNotBlank) ?: return
        prefs.edit().remove(itemsKey(key)).remove(savedAtKey(key)).apply()
    }

    private fun itemsKey(sourceId: String) = "home.$sourceId.items"
    private fun savedAtKey(sourceId: String) = "home.$sourceId.saved_at"

    private companion object {
        const val PREFS = "explore_home_cache_v1"
        const val MAX_ITEMS = 80
        const val MAX_AGE_MILLIS = 7L * 24L * 60L * 60L * 1_000L
    }
}
'''
write('app/src/main/java/vn/nghetruyen/app/ui/ExploreHomeCache.kt', home_cache)

# 2) Extension host pump: never deep-hash PlaybackSnapshot or library lists on every MainUiState emission.
pump = '''package vn.nghetruyen.app.sourceplatform

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import vn.nghetruyen.app.MainActivity
import vn.nghetruyen.app.playback.PlaybackQueueStore
import vn.nghetruyen.app.ui.AppViewModel
import vn.nghetruyen.app.ui.Destination
import vn.nghetruyen.app.ui.MainUiState
import vn.nghetruyen.app.ui.RootTab
import vn.nghetruyen.source.api.JsonValue
import vn.nghetruyen.source.api.SourceHostEventBus
import vn.nghetruyen.source.api.SourceHostKernelContract
import java.lang.ref.WeakReference
import java.util.WeakHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/** Converts app state transitions into lightweight extension host events. */
object ExtensionHostEventPump {
    private val jobs = WeakHashMap<AppViewModel, List<Job>>()
    private val activeHost = AtomicReference<WeakReference<AppViewModel>?>(null)
    private val lifecycleRegistered = AtomicBoolean(false)

    fun install(viewModel: AppViewModel) {
        activeHost.set(WeakReference(viewModel))
        registerActivityLifecycle(viewModel.getApplication())
        synchronized(jobs) {
            if (jobs[viewModel]?.any(Job::isActive) == true) return

            var previousNavigation: NavigationSnapshot? = null
            val navigationJob = viewModel.viewModelScope.launch {
                viewModel.state
                    .map(NavigationSnapshot::from)
                    .distinctUntilChanged()
                    .collect { current ->
                        val previous = previousNavigation
                        if (previous == null) {
                            emit(current.sourceId, "app.start", JsonValue.Obj())
                        } else {
                            emitNavigationTransitions(previous, current)
                        }
                        previousNavigation = current
                    }
            }

            var previousPlayback: PlaybackSignal? = null
            val playbackJob = viewModel.viewModelScope.launch {
                PlaybackQueueStore.state
                    .map { playback -> PlaybackSignal(
                        sourceId = playback.sourceId,
                        chapterId = playback.chapterId,
                        paragraphIndex = playback.paragraphIndex,
                        speechChunkIndex = playback.speechChunkIndex,
                        isPlaying = playback.isPlaying,
                        rate = playback.rate,
                        pitch = playback.pitch,
                        volume = playback.volume,
                        preparationState = playback.preparationState.name,
                        narrationStage = playback.narrationStage.name,
                    ) }
                    .distinctUntilChanged()
                    .collect { current ->
                        if (previousPlayback != null) {
                            val sourceId = current.sourceId.ifBlank { activeHost.get()?.get()?.state?.value?.selectedSourceId.orEmpty() }
                            emit(sourceId, "playback.changed", JsonValue.Obj(linkedMapOf(
                                "chapterId" to JsonValue.Str(current.chapterId),
                                "paragraphIndex" to jsonNumber(current.paragraphIndex),
                            )))
                        }
                        previousPlayback = current
                    }
            }

            var firstLibraryEmission = true
            val libraryJob = viewModel.viewModelScope.launch {
                viewModel.libraryRevision.collect {
                    if (firstLibraryEmission) {
                        firstLibraryEmission = false
                        return@collect
                    }
                    val state = viewModel.state.value
                    emit(NavigationSnapshot.sourceId(state), "library.changed", JsonValue.Obj(linkedMapOf(
                        "reading" to jsonNumber(state.readingStories.size),
                        "downloaded" to jsonNumber(state.downloadedStories.size),
                        "bookmarks" to jsonNumber(state.bookmarks.size),
                        "notes" to jsonNumber(state.notes.size),
                        "following" to jsonNumber(state.following.size),
                    )))
                }
            }

            val installed = listOf(navigationJob, playbackJob, libraryJob)
            installed.forEach { job ->
                job.invokeOnCompletion {
                    synchronized(jobs) {
                        val current = jobs[viewModel].orEmpty().filter(Job::isActive)
                        if (current.isEmpty()) jobs.remove(viewModel) else jobs[viewModel] = current
                    }
                }
            }
            jobs[viewModel] = installed
        }
    }

    private fun registerActivityLifecycle(application: Application) {
        if (!lifecycleRegistered.compareAndSet(false, true)) return
        application.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) {
                if (activity is MainActivity) emitForActiveHost("app.resume")
            }

            override fun onActivityPaused(activity: Activity) {
                if (activity is MainActivity) emitForActiveHost("app.pause")
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityStarted(activity: Activity) = Unit
            override fun onActivityStopped(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })
    }

    private fun emitForActiveHost(name: String) {
        val host = activeHost.get()?.get() ?: return
        val state = host.state.value
        emit(NavigationSnapshot.sourceId(state), name, JsonValue.Obj())
    }

    private fun emitNavigationTransitions(previous: NavigationSnapshot, current: NavigationSnapshot) {
        if (previous.destination != current.destination || previous.sourceId != current.sourceId) {
            if (previous.destination == Destination.Reader) {
                emit(previous.sourceId, "reader.leave", JsonValue.Obj(linkedMapOf(
                    "chapterId" to JsonValue.Str(previous.chapterId),
                )))
            }
            when (current.destination) {
                Destination.Root -> if (current.rootTab == RootTab.EXPLORE) {
                    emit(current.sourceId, "explore.enter", JsonValue.Obj())
                }
                Destination.Story -> emit(current.sourceId, "story.enter", JsonValue.Obj(linkedMapOf(
                    "storyId" to JsonValue.Str(current.storyId),
                )))
                Destination.Reader -> emit(current.sourceId, "reader.enter", JsonValue.Obj(linkedMapOf(
                    "chapterId" to JsonValue.Str(current.chapterId),
                    "paragraphIndex" to jsonNumber(PlaybackQueueStore.state.value.paragraphIndex),
                )))
            }
        }

        if (current.chapterId.isNotBlank() && current.chapterId != previous.chapterId) {
            emit(current.sourceId, "reader.chapterChanged", JsonValue.Obj(linkedMapOf(
                "chapterId" to JsonValue.Str(current.chapterId),
                "previousChapterId" to JsonValue.Str(previous.chapterId),
            )))
        }
    }

    private fun emit(sourceId: String, name: String, payload: JsonValue.Obj) {
        if (sourceId.isBlank()) return
        SourceHostEventBus.emit(
            sourceId = sourceId,
            event = SourceHostKernelContract.event(name, payload),
            traceId = "host-event-${System.nanoTime()}",
        )
    }

    private fun jsonNumber(value: Int): JsonValue.Num = JsonValue.Num(value.toDouble(), value.toString())

    private data class NavigationSnapshot(
        val sourceId: String,
        val destination: Destination,
        val rootTab: RootTab,
        val storyId: String,
        val chapterId: String,
    ) {
        companion object {
            fun from(state: MainUiState): NavigationSnapshot = NavigationSnapshot(
                sourceId = sourceId(state),
                destination = state.destination,
                rootTab = state.rootTab,
                storyId = state.storyDetail?.story?.id.orEmpty(),
                chapterId = state.chapterContent?.chapter?.id.orEmpty(),
            )

            fun sourceId(state: MainUiState): String =
                state.storyDetail?.story?.sourceId?.takeIf(String::isNotBlank) ?: state.selectedSourceId
        }
    }

    private data class PlaybackSignal(
        val sourceId: String,
        val chapterId: String,
        val paragraphIndex: Int,
        val speechChunkIndex: Int,
        val isPlaying: Boolean,
        val rate: Float,
        val pitch: Float,
        val volume: Float,
        val preparationState: String,
        val narrationStage: String,
    )
}
'''
write('app/src/main/java/vn/nghetruyen/app/sourceplatform/ExtensionHostEventPump.kt', pump)

# 3) Reuse OkHttp connection pool across built-in source adapters.
for path in [
    'app/src/main/java/vn/nghetruyen/app/sources/HttpHtmlClient.kt',
    'app/src/main/java/vn/nghetruyen/app/sources/HttpTextClient.kt',
]:
    text = read(path)
    text = replace_once(
        text,
        'private val client: OkHttpClient = defaultClient(),',
        'private val client: OkHttpClient = SHARED_CLIENT,',
        path + ' shared client ctor',
    )
    if 'HttpHtmlClient.kt' in path:
        old = '''        private fun defaultClient(): OkHttpClient = OkHttpClient.Builder()\n            .connectTimeout(Duration.ofSeconds(15))\n            .readTimeout(Duration.ofSeconds(30))\n            .callTimeout(Duration.ofSeconds(45))\n            .followRedirects(false)\n            .followSslRedirects(false)\n            .retryOnConnectionFailure(true)\n            .build()'''
        new = '''        private val SHARED_CLIENT: OkHttpClient = OkHttpClient.Builder()\n            .connectTimeout(Duration.ofSeconds(15))\n            .readTimeout(Duration.ofSeconds(30))\n            .callTimeout(Duration.ofSeconds(45))\n            .followRedirects(false)\n            .followSslRedirects(false)\n            .retryOnConnectionFailure(true)\n            .build()'''
    else:
        old = '''        private fun defaultClient(): OkHttpClient = OkHttpClient.Builder()\n            .connectTimeout(Duration.ofSeconds(15))\n            .readTimeout(Duration.ofSeconds(30))\n            .callTimeout(Duration.ofSeconds(45))\n            .followRedirects(false)\n            .followSslRedirects(false)\n            .retryOnConnectionFailure(true)\n            .build()'''
        new = '''        private val SHARED_CLIENT: OkHttpClient = OkHttpClient.Builder()\n            .connectTimeout(Duration.ofSeconds(15))\n            .readTimeout(Duration.ofSeconds(30))\n            .callTimeout(Duration.ofSeconds(45))\n            .followRedirects(false)\n            .followSslRedirects(false)\n            .retryOnConnectionFailure(true)\n            .build()'''
    text = replace_once(text, old, new, path + ' shared client declaration')
    write(path, text)

# 4) AppContainer: do not construct diagnostics before MainActivity arms StartupWorkGate.
path = 'app/src/main/java/vn/nghetruyen/app/AppContainer.kt'
text = read(path)
text = replace_once(
    text,
    '    val sourceDiagnostics: SourceDiagnosticRuntime = SourceDiagnosticRuntime(appContext)\n    private val screenScopedSourceEvidence = ScreenScopedDiagnosticEvidenceSink(\n        scope = sourceDiagnostics.recorder,\n        delegate = sourceDiagnostics.evidence,\n    )',
    '    val sourceDiagnostics: SourceDiagnosticRuntime by lazy { SourceDiagnosticRuntime(appContext) }\n    private val screenScopedSourceEvidence by lazy {\n        ScreenScopedDiagnosticEvidenceSink(\n            scope = sourceDiagnostics.recorder,\n            delegate = sourceDiagnostics.evidence,\n        )\n    }',
    'app container lazy diagnostics',
)
write(path, text)

# 5) Diagnostics runtime: keep persistent disk work off critical startup path.
path = 'app/src/main/java/vn/nghetruyen/app/sourceplatform/SourceDiagnosticRuntime.kt'
text = read(path)
text = replace_once(
    text,
    'import kotlinx.coroutines.flow.update\n',
    'import kotlinx.coroutines.CoroutineScope\nimport kotlinx.coroutines.Dispatchers\nimport kotlinx.coroutines.SupervisorJob\nimport kotlinx.coroutines.flow.update\nimport kotlinx.coroutines.launch\n',
    'diagnostics coroutine imports',
)
text = replace_once(
    text,
    'import vn.nghetruyen.app.BuildConfig\n',
    'import vn.nghetruyen.app.BuildConfig\nimport vn.nghetruyen.app.startup.StartupWorkGate\n',
    'diagnostics StartupWorkGate import',
)
text = replace_once(
    text,
    '''    private val prefs = context.getSharedPreferences("source_diagnostics", Context.MODE_PRIVATE)\n    private val activityTracker = DiagnosticActivityTracker()\n    private val criticalStore = CriticalDiagnosticStore(context)\n    private val continuousStoreDelegate = lazy { ContinuousDiagnosticStore(context) }''',
    '''    private val prefs = context.getSharedPreferences("source_diagnostics", Context.MODE_PRIVATE)\n    private val activityTracker = DiagnosticActivityTracker()\n    private val diskScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)\n    private val criticalStoreDelegate = lazy { CriticalDiagnosticStore(context) }\n    private val criticalStore by criticalStoreDelegate\n    private val continuousStoreDelegate = lazy { ContinuousDiagnosticStore(context) }''',
    'diagnostics lazy stores',
)
text = replace_once(
    text,
    '''    private val criticalMirror = DiagnosticSink { event ->\n        criticalStore.emit(event)\n        if (PersistentCriticalDiagnosticPolicy.shouldPersist(event)) signalChanged()\n    }''',
    '''    private val criticalMirror = DiagnosticSink { event ->\n        if (!PersistentCriticalDiagnosticPolicy.shouldPersist(event)) return@DiagnosticSink\n        criticalStore.emit(event)\n        signalChanged()\n    }''',
    'critical mirror lazy',
)
text = replace_once(
    text,
    '''    private val mirror = DiagnosticSink { event ->\n        activityTracker.emit(event)\n        if (mode == MODE_CONTINUOUS) continuousStore.emit(event)\n        signalChanged()\n    }\n    private val evidenceMirror = object : DiagnosticEvidenceSink {\n        override val enabled: Boolean get() = mode == MODE_CONTINUOUS\n        override fun capture(evidence: DiagnosticEvidence) {\n            if (mode == MODE_CONTINUOUS) continuousStore.capture(evidence)\n            signalChanged()\n        }\n    }''',
    '''    private val mirror = DiagnosticSink { event ->\n        activityTracker.emit(event)\n        if (mode == MODE_CONTINUOUS) continuousStoreForWrite().emit(event)\n        signalChanged()\n    }\n    private val evidenceMirror = object : DiagnosticEvidenceSink {\n        override val enabled: Boolean get() = mode == MODE_CONTINUOUS\n        override fun capture(evidence: DiagnosticEvidence) {\n            if (mode == MODE_CONTINUOUS) continuousStoreForWrite().capture(evidence)\n            signalChanged()\n        }\n    }''',
    'continuous mirror lazy',
)
text = replace_once(
    text,
    '''    init {\n        val restoredMode = normalizeMode(prefs.getString(KEY_MODE, MODE_OFF).orEmpty())\n        mode = restoredMode\n        applyMode(restoredMode)\n        if (restoredMode == MODE_CONTINUOUS) {\n            recorder.restore(continuousStore.restoreRecentEvents(MAX_IN_MEMORY_EVENTS))\n            restoreCriticalHistory()\n        }\n    }''',
    '''    init {\n        val restoredMode = normalizeMode(prefs.getString(KEY_MODE, MODE_OFF).orEmpty())\n        mode = restoredMode\n        applyMode(restoredMode)\n        if (StartupWorkGate.isBeforeFirstFrame()) {\n            diskScope.launch {\n                if (StartupWorkGate.awaitFirstFrame()) hydratePersistentState()\n            }\n        } else {\n            hydratePersistentState()\n        }\n    }\n\n    private fun hydratePersistentState() {\n        if (mode == MODE_CONTINUOUS) {\n            recorder.restore(continuousStoreForWrite().restoreRecentEvents(MAX_IN_MEMORY_EVENTS))\n        }\n        if (mode == MODE_CONTINUOUS || criticalStoreDelegate.isInitialized()) restoreCriticalHistory()\n        signalChanged()\n    }\n\n    private fun continuousStoreForWrite(): ContinuousDiagnosticStore = continuousStore.apply {\n        enabled = mode == MODE_CONTINUOUS\n    }''',
    'diagnostics deferred hydration',
)
text = replace_once(
    text,
    '    private fun hydratePersistentState() {\n        if (mode == MODE_CONTINUOUS) {\n            recorder.restore(continuousStoreForWrite().restoreRecentEvents(MAX_IN_MEMORY_EVENTS))\n        }\n        if (mode == MODE_CONTINUOUS || criticalStoreDelegate.isInitialized()) restoreCriticalHistory()\n        signalChanged()\n    }',
    '    private fun hydratePersistentState() {\n        criticalStore\n        if (mode == MODE_CONTINUOUS) {\n            recorder.restore(continuousStoreForWrite().restoreRecentEvents(MAX_IN_MEMORY_EVENTS))\n            restoreCriticalHistory()\n        }\n        signalChanged()\n    }',
    'diagnostics hydrate critical after frame',
)
text = replace_once(
    text,
    '''    fun persistentCriticalCount(): Int = criticalStore.eventCount\n\n    /**\n     * Durable install/import history is visible as a fallback only while session diagnostics are off.\n     * Screen/continuous modes must never mix old persisted failures into their live timeline.\n     */\n    fun persistentCriticalSnapshot(): List<DiagnosticEvent> =\n        if (mode == MODE_OFF) criticalStore.snapshot() else emptyList()''',
    '''    fun persistentCriticalCount(): Int = criticalStore.eventCount\n\n    fun cachedPersistentCriticalCount(): Int =\n        if (criticalStoreDelegate.isInitialized()) criticalStore.eventCount else 0\n\n    fun sessionEventCount(): Int = recorder.stats().itemCount\n\n    /**\n     * Durable install/import history is visible as a fallback only while session diagnostics are off.\n     * Screen/continuous modes must never mix old persisted failures into their live timeline.\n     */\n    fun persistentCriticalSnapshot(): List<DiagnosticEvent> =\n        if (mode == MODE_OFF) criticalStore.snapshot() else emptyList()''',
    'diagnostics cheap counters',
)
text = replace_once(
    text,
    '''        if (value == MODE_CONTINUOUS) {\n            continuousStore.enabled = true\n        } else if (continuousStoreDelegate.isInitialized()) {\n            continuousStore.enabled = false\n        }''',
    '''        if (continuousStoreDelegate.isInitialized()) {\n            continuousStore.enabled = value == MODE_CONTINUOUS\n        }''',
    'diagnostics apply mode no eager store',
)
write(path, text)

# 5) AppViewModel startup, diagnostics, UI projection and library revision.
path = 'app/src/main/java/vn/nghetruyen/app/ui/AppViewModel.kt'
text = read(path)
text = replace_once(text, 'import kotlinx.coroutines.flow.distinctUntilChanged\n', 'import kotlinx.coroutines.flow.SharingStarted\nimport kotlinx.coroutines.flow.collectLatest\nimport kotlinx.coroutines.flow.combine\nimport kotlinx.coroutines.flow.distinctUntilChanged\n', 'vm flow imports 1')
text = replace_once(text, 'import kotlinx.coroutines.flow.update\n', 'import kotlinx.coroutines.flow.update\nimport kotlinx.coroutines.flow.stateIn\n', 'vm flow imports 2')

old_init_state = '''    private val mutableState = MutableStateFlow(\n        MainUiState(\n            sources = container.sourceRegistry.descriptors(),\n            sourcePacks = container.sourcePlatformManager.installedPacks(),\n            sourceRepositories = container.sourcePlatformManager.repositories(),\n            sourceRepositoryPackages = container.sourcePlatformManager.repositoryPackages(),\n            sourceTrustKeys = container.sourcePlatformManager.trustKeys(),\n            sourceDiagnosticCount = visibleDiagnosticEvents().size,\n            sourceDiagnostics = visibleDiagnosticSummaries(),\n            sourceTraces = container.sourcePlatformManager.diagnosticTraces(100),\n            diagnosticsMode = container.sourceDiagnostics.mode,\n            diagnosticActiveOperations = container.sourceDiagnostics.activityLines(),\n            diagnosticPersistentCriticalCount = container.sourceDiagnostics.persistentCriticalCount(),\n            backupHistory = container.backupHistoryStore.entries(),\n            backupLogPath = container.backupHistoryStore.logPath(),\n            backupLogText = container.backupHistoryStore.logText(),\n            vietPhraseEnabled = referenceVietPhraseRuntime.enabled,\n            vietPhraseFallbackHanViet = referenceVietPhraseRuntime.fallbackHanViet,\n        ),\n    )\n    val state: StateFlow<MainUiState> = mutableState.asStateFlow()'''
new_init_state = '''    private val mutableState = MutableStateFlow(
        MainUiState(
            sources = container.sourceRegistry.descriptors(),
            diagnosticsMode = container.sourceDiagnostics.mode,
            vietPhraseEnabled = referenceVietPhraseRuntime.enabled,
            vietPhraseFallbackHanViet = referenceVietPhraseRuntime.fallbackHanViet,
        ),
    )
    val state: StateFlow<MainUiState> = mutableState.asStateFlow()
    private val mutablePersonalPage = MutableStateFlow("")
    val compositionState: StateFlow<MainUiState> = combine(state, mutablePersonalPage) { current, personalPage ->
        current.forActiveComposition(personalPage)
    }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, mutableState.value.forActiveComposition(""))

    private val mutableLibraryRevision = MutableStateFlow(0L)
    val libraryRevision: StateFlow<Long> = mutableLibraryRevision.asStateFlow()
    private val exploreHomeCache = ExploreHomeCache(application)
    private var diagnosticOverlayVisible = false
    private var activePersonalPage = ""'''
text = replace_once(text, old_init_state, new_init_state, 'vm initial state')

old_init = '''    init {\n        observeSettings()\n        observeDiagnostics()\n        observePlayback()\n        refreshTtsVoices()\n        refreshSourceSessions()\n        refreshSourcePlatformState()\n        restorePersistedSourceRepositories()\n        refreshAiCredentialState()\n        viewModelScope.launch { container.libraryRepository.ensureGlobalVoiceProfiles() }\n        search("")\n    }'''
new_init = '''    init {\n        observeSettings()\n        observeDiagnostics()\n        observePlayback()\n        viewModelScope.launch {\n            if (!StartupWorkGate.awaitFirstFrameAsync()) return@launch\n            refreshTtsVoices()\n            refreshSourceSessions()\n            refreshSourcePlatformState()\n            restorePersistedSourceRepositories()\n            refreshAiCredentialState()\n            withContext(Dispatchers.IO) { container.libraryRepository.ensureGlobalVoiceProfiles() }\n            restoreCachedHomeAndRefresh()\n        }\n    }'''
text = replace_once(text, old_init, new_init, 'vm init deferred')

# Do not trigger network Home from the first settings emission, and never touch Android Keystore synchronously there.
text = replace_once(
    text,
    '''                        readerDisplay = settings.readerDisplay,\n                        aiOnline = settings.aiOnline,\n                        aiHasApiKey = container.aiCredentialStore.hasApiKey(settings.aiOnline.provider),\n                        aiHasGeminiApiKey = container.aiCredentialStore.hasApiKey(AiProvider.GEMINI),\n                        aiHasOpenAiApiKey = container.aiCredentialStore.hasApiKey(AiProvider.OPENAI_COMPATIBLE),\n                    )''',
    '''                        readerDisplay = settings.readerDisplay,\n                        aiOnline = settings.aiOnline,\n                    )''',
    'vm settings keystore removal',
)
text = replace_once(text, '    fun refreshAiCredentialState() {\n        val provider = mutableState.value.aiOnline.provider\n        mutableState.update {\n            it.copy(\n                aiHasApiKey = container.aiCredentialStore.hasApiKey(provider),\n                aiHasGeminiApiKey = container.aiCredentialStore.hasApiKey(AiProvider.GEMINI),\n                aiHasOpenAiApiKey = container.aiCredentialStore.hasApiKey(AiProvider.OPENAI_COMPATIBLE),\n            )\n        }\n    }', '    fun refreshAiCredentialState() {\n        val provider = mutableState.value.aiOnline.provider\n        viewModelScope.launch {\n            val flags = withContext(Dispatchers.IO) {\n                Triple(\n                    container.aiCredentialStore.hasApiKey(provider),\n                    container.aiCredentialStore.hasApiKey(AiProvider.GEMINI),\n                    container.aiCredentialStore.hasApiKey(AiProvider.OPENAI_COMPATIBLE),\n                )\n            }\n            mutableState.update {\n                it.copy(\n                    aiHasApiKey = flags.first,\n                    aiHasGeminiApiKey = flags.second,\n                    aiHasOpenAiApiKey = flags.third,\n                )\n            }\n        }\n    }', 'vm async credential refresh')
text = replace_once(
    text,
    '                if (sourceChanged) search("")\n',
    '''                if (sourceChanged && !StartupWorkGate.isBeforeFirstFrame()) {\n                    restoreCachedHomeAndRefresh()\n                }\n''',
    'vm settings startup search gate',
)

# Coalesce diagnostic updates and only materialize expensive details while actually visible.
old_diag_observer = '''    private fun observeDiagnostics() {\n        viewModelScope.launch {\n            container.sourceDiagnostics.changes.collect {\n                val events = visibleDiagnosticEvents()\n                mutableState.update { current ->\n                    current.copy(\n                        diagnosticsMode = container.sourceDiagnostics.mode,\n                        diagnosticActiveOperations = container.sourceDiagnostics.activityLines(),\n                        diagnosticPersistentCriticalCount = container.sourceDiagnostics.persistentCriticalCount(),\n                        sourceDiagnosticCount = events.size,\n                        sourceDiagnostics = diagnosticSummaries(events),\n                        sourceTraces = container.sourcePlatformManager.diagnosticTraces(100),\n                    )\n                }\n            }\n        }\n    }'''
new_diag_observer = '''    private fun observeDiagnostics() {\n        viewModelScope.launch {\n            container.sourceDiagnostics.changes.collectLatest {\n                delay(DIAGNOSTIC_UI_DEBOUNCE_MS)\n                refreshDiagnosticUi(loadDetails = shouldMaterializeDiagnosticDetails())\n            }\n        }\n    }\n\n    fun setDiagnosticOverlayVisible(visible: Boolean) {\n        if (diagnosticOverlayVisible == visible) return\n        diagnosticOverlayVisible = visible\n        refreshDiagnosticUi(loadDetails = visible || shouldMaterializeDiagnosticDetails())\n    }\n\n    fun onPersonalPageChanged(page: String) {\n        activePersonalPage = page\n        val needsSourcePlatform = page.startsWith("extensions_") || page == "settings_diagnostics"\n        if (needsSourcePlatform) refreshSourcePlatformState()\n        refreshDiagnosticUi(loadDetails = shouldMaterializeDiagnosticDetails())\n    }\n\n    private fun shouldMaterializeDiagnosticDetails(): Boolean =\n        diagnosticOverlayVisible || activePersonalPage == "settings_diagnostics" || activePersonalPage == "extensions_diagnostics"\n\n    private fun refreshDiagnosticUi(loadDetails: Boolean) {\n        val runtime = container.sourceDiagnostics\n        viewModelScope.launch {\n            val details = if (loadDetails) withContext(Dispatchers.Default) {\n                val events = visibleDiagnosticEvents()\n                DiagnosticUiDetails(\n                    count = events.size,\n                    summaries = diagnosticSummaries(events),\n                    traces = container.sourcePlatformManager.diagnosticTraces(100),\n                )\n            } else null\n            mutableState.update { current ->\n                current.copy(\n                    diagnosticsMode = runtime.mode,\n                    diagnosticActiveOperations = runtime.activityLines(),\n                    diagnosticPersistentCriticalCount = runtime.cachedPersistentCriticalCount(),\n                    sourceDiagnosticCount = details?.count ?: runtime.sessionEventCount() + runtime.cachedPersistentCriticalCount(),\n                    sourceDiagnostics = details?.summaries ?: emptyList(),\n                    sourceTraces = details?.traces ?: emptyList(),\n                )\n            }\n        }\n    }'''
text = replace_once(text, old_diag_observer, new_diag_observer, 'vm diagnostics observer')

# Bump a tiny revision only when library collections that extensions care about actually change.
replacements = {
    '.collect { items -> mutableState.update { it.copy(readingStories = items) } }': '.collect { items ->\n                            mutableState.update { it.copy(readingStories = items) }\n                            bumpLibraryRevision()\n                        }',
    '.collect { items -> mutableState.update { it.copy(downloadedStories = items) } }': '.collect { items ->\n                        mutableState.update { it.copy(downloadedStories = items) }\n                        bumpLibraryRevision()\n                    }',
    '.collect { items -> mutableState.update { it.copy(bookmarks = items) } }': '.collect { items ->\n                        mutableState.update { it.copy(bookmarks = items) }\n                        bumpLibraryRevision()\n                    }',
    '.collect { items -> mutableState.update { it.copy(notes = items) } }': '.collect { items ->\n                        mutableState.update { it.copy(notes = items) }\n                        bumpLibraryRevision()\n                    }',
    '.collect { items -> mutableState.update { it.copy(following = items) } }': '.collect { items ->\n                        mutableState.update { it.copy(following = items) }\n                        bumpLibraryRevision()\n                    }',
}
for old, new in replacements.items():
    text = replace_once(text, old, new, 'vm library revision ' + old[:25])

# Source platform refresh no longer rebuilds diagnostics and is moved off main thread.
old_refresh = '''    private fun refreshSourcePlatformState() {\n        container.sourceRegistry.refreshSourcePacks(container.sourcePlatformManager.activeStorySources())\n        mutableState.update { current ->\n            current.copy(\n                sources = container.sourceRegistry.descriptors(),\n                sourcePacks = container.sourcePlatformManager.installedPacks(),\n                sourceRepositories = container.sourcePlatformManager.repositories(),\n                sourceRepositoryPackages = container.sourcePlatformManager.repositoryPackages(),\n                sourceTrustKeys = container.sourcePlatformManager.trustKeys(),\n                sourceDiagnosticCount = visibleDiagnosticEvents().size,\n                sourceDiagnostics = visibleDiagnosticSummaries(),\n                sourceTraces = container.sourcePlatformManager.diagnosticTraces(100),\n                diagnosticActiveOperations = container.sourceDiagnostics.activityLines(),\n                diagnosticPersistentCriticalCount = container.sourceDiagnostics.persistentCriticalCount(),\n            )\n        }\n    }'''
new_refresh = '''    private fun refreshSourcePlatformState() {\n        viewModelScope.launch {\n            val snapshot = withContext(Dispatchers.IO) {\n                val active = container.sourcePlatformManager.activeStorySources()\n                container.sourceRegistry.refreshSourcePacks(active)\n                SourcePlatformUiSnapshot(\n                    sources = container.sourceRegistry.descriptors(),\n                    packs = container.sourcePlatformManager.installedPacks(),\n                    repositories = container.sourcePlatformManager.repositories(),\n                    packages = container.sourcePlatformManager.repositoryPackages(),\n                    trustKeys = container.sourcePlatformManager.trustKeys(),\n                )\n            }\n            mutableState.update { current ->\n                current.copy(\n                    sources = snapshot.sources,\n                    sourcePacks = snapshot.packs,\n                    sourceRepositories = snapshot.repositories,\n                    sourceRepositoryPackages = snapshot.packages,\n                    sourceTrustKeys = snapshot.trustKeys,\n                )\n            }\n        }\n    }'''
text = replace_once(text, old_refresh, new_refresh, 'vm source platform refresh')

# Remove now-unused helper that duplicated visibleDiagnosticEvents work.
text = replace_once(
    text,
    '''    private fun visibleDiagnosticSummaries(): List<SourceDiagnosticUi> =\n        diagnosticSummaries(visibleDiagnosticEvents())\n\n''',
    '',
    'vm visible diagnostic summaries removal',
)

# Lazy backup history/log, and make diagnostics export read backup tail only on user action.
old_refresh_backup = '''    fun refreshBackupLog(): Boolean {\n        val path = container.backupHistoryStore.logPath()\n        val text = container.backupHistoryStore.logText()\n        mutableState.update { it.copy(backupLogPath = path, backupLogText = text) }\n        if (text.isBlank()) showMessage("Chưa có nhật ký sao lưu hoặc khôi phục.")\n        return text.isNotBlank()\n    }'''
new_refresh_backup = '''    fun refreshBackupLog(): Boolean {\n        viewModelScope.launch {\n            val snapshot = withContext(Dispatchers.IO) {\n                Triple(\n                    container.backupHistoryStore.entries(),\n                    container.backupHistoryStore.logPath(),\n                    container.backupHistoryStore.logText(),\n                )\n            }\n            mutableState.update {\n                it.copy(backupHistory = snapshot.first, backupLogPath = snapshot.second, backupLogText = snapshot.third)\n            }\n            if (snapshot.third.isBlank()) showMessage("Chưa có nhật ký sao lưu hoặc khôi phục.")\n        }\n        return true\n    }'''
text = replace_once(text, old_refresh_backup, new_refresh_backup, 'vm lazy backup log')

text = replace_once(
    text,
    '                backupLogTail = state.value.backupLogText.takeLast(64_000),\n',
    '                backupLogTail = withContext(Dispatchers.IO) { container.backupHistoryStore.logText().takeLast(64_000) },\n',
    'vm diagnostics lazy backup export',
)

# Avoid reading full backup log after every backup/restore.
text = text.replace('backupHistory = container.backupHistoryStore.entries(), backupLogPath = container.backupHistoryStore.logPath(), backupLogText = container.backupHistoryStore.logText()', 'backupHistory = container.backupHistoryStore.entries(), backupLogPath = container.backupHistoryStore.logPath(), backupLogText = ""')

# Do not load all source-management state merely by opening Personal root.
text = replace_once(
    text,
    '''    fun setRootTab(tab: RootTab) {\n        mutableState.update { it.copy(destination = Destination.Root, rootTab = tab, message = null) }\n        if (tab == RootTab.PERSONAL) refreshSourcePlatformState()\n    }''',
    '''    fun setRootTab(tab: RootTab) {\n        mutableState.update { it.copy(destination = Destination.Root, rootTab = tab, message = null) }\n    }''',
    'vm setRootTab',
)

# Save successful first-page Home responses and restore cache before the network refresh.
old_success = '''                when (result) {\n                    is AppResult.Success -> mutableState.update {\n                        it.copy(\n                            loading = false,\n                            stories = mergeExploreStories(\n                                existing = emptyList(),\n                                incoming = result.value,\n                                source = source.descriptor,\n                                query = cleanQuery,\n                                sortMode = snapshot.searchSortMode,\n                                mode = if (cleanQuery.isBlank()) ExploreMode.HOME else ExploreMode.SEARCH,\n                            ),\n                            canLoadMoreStories = result.value.isNotEmpty(),\n                            searchedSourceCount = 1,\n                            totalSearchSourceCount = 1,\n                        )\n                    }\n                    is AppResult.Failure -> mutableState.update { it.copy(loading = false, message = result.message) }\n                }'''
new_success = '''                when (result) {\n                    is AppResult.Success -> {\n                        val merged = mergeExploreStories(\n                            existing = emptyList(),\n                            incoming = result.value,\n                            source = source.descriptor,\n                            query = cleanQuery,\n                            sortMode = snapshot.searchSortMode,\n                            mode = if (cleanQuery.isBlank()) ExploreMode.HOME else ExploreMode.SEARCH,\n                        )\n                        if (cleanQuery.isBlank()) withContext(Dispatchers.IO) {\n                            exploreHomeCache.save(source.descriptor.id, merged)\n                        }\n                        mutableState.update {\n                            it.copy(\n                                loading = false,\n                                stories = merged,\n                                canLoadMoreStories = result.value.isNotEmpty(),\n                                searchedSourceCount = 1,\n                                totalSearchSourceCount = 1,\n                            )\n                        }\n                    }\n                    is AppResult.Failure -> mutableState.update { current ->\n                        current.copy(\n                            loading = false,\n                            message = if (current.stories.isEmpty()) result.message else current.message,\n                        )\n                    }\n                }'''
text = replace_once(text, old_success, new_success, 'vm home cache save')

# Add helper/data classes and composition projection near the end before providerLabel.
anchor = '''    private companion object {\n        const val MANUAL_NARRATION_RETRY_DELAY_MS = 5_000L\n        const val MAX_READER_CATALOG_PAGE_HOPS = 30\n    }\n\n    private fun providerLabel'''
insert = '''    private fun bumpLibraryRevision() {\n        mutableLibraryRevision.update { current -> if (current == Long.MAX_VALUE) 1L else current + 1L }\n    }\n\n    private fun restoreCachedHomeAndRefresh() {\n        if (StartupWorkGate.isBeforeFirstFrame()) return\n        val snapshot = state.value\n        if (snapshot.destination != Destination.Root || snapshot.rootTab != RootTab.EXPLORE || snapshot.query.isNotBlank() || snapshot.searchAllSources) return\n        viewModelScope.launch {\n            val cached = withContext(Dispatchers.IO) { exploreHomeCache.load(snapshot.selectedSourceId) }\n            if (cached.isNotEmpty()) {\n                mutableState.update { current ->\n                    if (current.selectedSourceId != snapshot.selectedSourceId || current.query.isNotBlank() || current.searchAllSources) current\n                    else current.copy(\n                        stories = cached,\n                        exploreMode = ExploreMode.HOME,\n                        canLoadMoreStories = true,\n                    )\n                }\n            }\n            search("")\n        }\n    }\n\n    private data class DiagnosticUiDetails(\n        val count: Int,\n        val summaries: List<SourceDiagnosticUi>,\n        val traces: List<SourceTraceUi>,\n    )\n\n    private data class SourcePlatformUiSnapshot(\n        val sources: List<SourceDescriptor>,\n        val packs: List<SourcePackUiInfo>,\n        val repositories: List<SourceRepositoryUiInfo>,\n        val packages: List<SourceRepositoryPackageUiInfo>,\n        val trustKeys: List<SourceTrustKeyUi>,\n    )\n\n    private companion object {\n        const val MANUAL_NARRATION_RETRY_DELAY_MS = 5_000L\n        const val MAX_READER_CATALOG_PAGE_HOPS = 30\n        const val DIAGNOSTIC_UI_DEBOUNCE_MS = 120L\n    }\n\n    private fun providerLabel'''
text = replace_once(text, anchor, insert, 'vm helper insert')

# Append projection outside AppViewModel before final EOF. It intentionally masks only inactive-screen-heavy state.
projection = '''\nprivate fun MainUiState.forActiveComposition(personalPage: String): MainUiState = when {\n    destination == Destination.Root && rootTab == RootTab.EXPLORE -> copy(\n        readingStories = emptyList(),\n        readingProgress = emptyMap(),\n        readingChapterTitles = emptyMap(),\n        readingHistory = emptyList(),\n        downloadedStories = emptyList(),\n        bookmarks = emptyList(),\n        notes = emptyList(),\n        following = emptyList(),\n        downloads = emptyList(),\n        downloadFailures = emptyList(),\n        playback = PlaybackSnapshot(),\n        offlineStorage = emptyMap(),\n        downloadedChapterIds = emptySet(),\n        storageUsage = StorageUsage(0, 0, 0, 0),\n        pronunciations = emptyList(),\n        vietPhraseRules = emptyList(),\n        vietPhraseSnapshots = emptyList(),\n        vietPhraseDictionaryStates = emptyList(),\n        vietPhraseSuggestions = emptyList(),\n        backupHistory = emptyList(),\n        backupLogPath = "",\n        backupLogText = "",\n        sceneMusicTracks = emptyList(),\n        storyTtsProfiles = emptyMap(),\n        storyAiProfiles = emptyMap(),\n        voiceRoles = emptyList(),\n        audioExports = emptyList(),\n        sourcePacks = emptyList(),\n        sourceRepositories = emptyList(),\n        sourceRepositoryPackages = emptyList(),\n        sourceTrustKeys = emptyList(),\n    )\n    destination == Destination.Root && rootTab == RootTab.LIBRARY -> copy(\n        stories = emptyList(),\n        sourceSuggestions = emptyList(),\n        playback = PlaybackSnapshot(),\n        pronunciations = emptyList(),\n        vietPhraseRules = emptyList(),\n        vietPhraseSnapshots = emptyList(),\n        vietPhraseDictionaryStates = emptyList(),\n        vietPhraseSuggestions = emptyList(),\n        backupHistory = emptyList(),\n        backupLogPath = "",\n        backupLogText = "",\n        sceneMusicTracks = emptyList(),\n        storyTtsProfiles = emptyMap(),\n        storyAiProfiles = emptyMap(),\n        voiceRoles = emptyList(),\n        audioExports = emptyList(),\n        sourcePacks = emptyList(),\n        sourceRepositories = emptyList(),\n        sourceRepositoryPackages = emptyList(),\n        sourceTrustKeys = emptyList(),\n    )\n    else -> this\n}\n'''
projection = replace_once(
    projection,
    '    else -> this\n}\n',
    '    destination == Destination.Root && rootTab == RootTab.PERSONAL -> copy(\n        stories = emptyList(),\n        sourceSuggestions = emptyList(),\n        chapterContent = null,\n        originalChapterContent = null,\n        playback = if (personalPage == \"settings_tts\") PlaybackSnapshot(\n            rate = playback.rate,\n            pitch = playback.pitch,\n            volume = playback.volume,\n        ) else PlaybackSnapshot(),\n    )\n    else -> this\n}\n',
    'personal composition projection',
)
if not text.endswith('\n'):
    text += '\n'
text += projection
write(path, text)

# 6) Reference app consumes the projected state and lets diagnostics/personal page explicitly request heavy details.
path = 'app/src/main/java/vn/nghetruyen/app/ui/ReferenceNgheTruyenApp.kt'
text = read(path)
text = replace_once(text, '    val state by viewModel.state.collectAsStateWithLifecycle()\n', '    val state by viewModel.compositionState.collectAsStateWithLifecycle()\n', 'reference composition state')
text = replace_once(
    text,
    '''                ReferenceDiagnosticsChrome(\n                    state = state,\n                    onExport = onExportSourceDiagnostics,\n                    onClear = viewModel::clearSourceDiagnostics,\n                )''',
    '''                ReferenceDiagnosticsChrome(\n                    state = state,\n                    onExport = onExportSourceDiagnostics,\n                    onClear = viewModel::clearSourceDiagnostics,\n                    onVisibilityChanged = viewModel::setDiagnosticOverlayVisible,\n                )''',
    'reference diagnostics visibility',
)
text = replace_once(
    text,
    '''                        onDiagnosticScreenChanged = { key ->\n                            app.container.sourceDiagnostics.onScreenChanged("personal:$key")\n                        },''',
    '''                        onDiagnosticScreenChanged = { key ->\n                            app.container.sourceDiagnostics.onScreenChanged("personal:$key")\n                            viewModel.onPersonalPageChanged(key)\n                        },''',
    'reference personal page callback',
)
write(path, text)

# 7) Diagnostics Chrome reports visibility so expensive event formatting exists only while dialog is open.
path = 'app/src/main/java/vn/nghetruyen/app/ui/components/ReferenceDiagnosticsChrome.kt'
text = read(path)
text = replace_once(text, 'import androidx.compose.runtime.Composable\n', 'import androidx.compose.runtime.Composable\nimport androidx.compose.runtime.DisposableEffect\n', 'diagnostics chrome disposable import')
text = replace_once(
    text,
    '    if (state.diagnosticsMode == \"off\" && state.diagnosticPersistentCriticalCount == 0) return\n\n    var showLog by remember { mutableStateOf(false) }',
    '    var showLog by remember { mutableStateOf(false) }',
    'diagnostics chrome defer early return',
)
text = replace_once(
    text,
    '''fun ReferenceDiagnosticsChrome(\n    state: MainUiState,\n    onExport: () -> Unit,\n    onClear: () -> Unit,\n) {''',
    '''fun ReferenceDiagnosticsChrome(\n    state: MainUiState,\n    onExport: () -> Unit,\n    onClear: () -> Unit,\n    onVisibilityChanged: (Boolean) -> Unit = {},\n) {''',
    'diagnostics chrome signature',
)
text = replace_once(
    text,
    '''    LaunchedEffect(state.diagnosticsMode) {\n        if (state.diagnosticsMode == "off") showLog = false\n    }''',
    '''    LaunchedEffect(state.diagnosticsMode) {\n        if (state.diagnosticsMode == "off") {\n            showLog = false\n            onVisibilityChanged(false)\n        }\n    }\n    LaunchedEffect(showLog) {\n        onVisibilityChanged(showLog)\n    }''',
    'diagnostics visibility effect',
)
text = replace_once(
    text,
    '    LaunchedEffect(showLog) {\n        onVisibilityChanged(showLog)\n    }\n\n    val recording',
    '    LaunchedEffect(showLog) {\n        onVisibilityChanged(showLog)\n    }\n    DisposableEffect(Unit) {\n        onDispose { onVisibilityChanged(false) }\n    }\n\n    if (state.diagnosticsMode == \"off\" && state.diagnosticPersistentCriticalCount == 0) return\n\n    val recording',
    'diagnostics chrome dispose visibility',
)
text = replace_once(
    text,
    '            onDismiss = { showLog = false },\n',
    '            onDismiss = { showLog = false; onVisibilityChanged(false) },\n',
    'diagnostics close visibility',
)
write(path, text)

print('all patches applied')
