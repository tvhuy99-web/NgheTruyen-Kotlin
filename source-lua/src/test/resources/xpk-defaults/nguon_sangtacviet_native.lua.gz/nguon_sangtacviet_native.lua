local function js_quote(value)
value = tostring(value or "")
value = value:gsub("\\", "\\\\"):gsub("'", "\\'"):gsub("\r", "\\r"):gsub("\n", "\\n")
return "'" .. value .. "'"
end
local function make_apply_filters_script(route)
local r = js_quote(route)
return [[
(function(){
var route = ]] .. r .. [[;
var p;
try { p = new URL(route, location.href).searchParams; } catch(e) { return 'route-error'; }
function clean(s){ return String(s||'').replace(/\s+/g,' ').trim(); }
function norm(s){
s = clean(s).toLowerCase();
try { s = s.normalize('NFD').replace(/[\u0300-\u036f]/g,''); } catch(e) {}
return s;
}
function aliases(wanted){
var w=norm(wanted), out=[w];
var map={
'moi cap nhat':['lasted update','latest update','recent update','newly updated'],
'luot xem tuan':['weekly reads','weekly read','week views'],
'hoan thanh':['finished','complete','completed'],
'con tiep':['ongoing'],
'huyen huyen':['fantasy'],
'do thi':['urban','urban fiction'],
'ngon tinh':['romance'],
'dong nhan':['fanfic','fan fiction'],
'khoa hoc vien tuong':['science fiction','sci-fi']
};
var more=map[w]||[]; for(var i=0;i<more.length;i++) out.push(norm(more[i]));
return out.filter(function(x,i,a){return x&&a.indexOf(x)===i;});
}
function findOption(wanted){
var wants = aliases(wanted);
if(!wants.length) return null;
var selects = Array.prototype.slice.call(document.querySelectorAll('select'));
for(var i=0;i<selects.length;i++){
var opts = Array.prototype.slice.call(selects[i].options||[]);
for(var j=0;j<opts.length;j++){
var t = norm(opts[j].textContent), v = norm(opts[j].value);
for(var k=0;k<wants.length;k++){
var w=wants[k];
if(t===w || v===w || (w.length>=4 && t.indexOf(w)>=0)){
return {select:selects[i], index:j};
}
}
}
}
return null;
}
function selectWanted(wanted, changed){
var hit = findOption(wanted);
if(!hit) return changed;
if(hit.select.selectedIndex !== hit.index){
hit.select.selectedIndex = hit.index;
try{ hit.select.dispatchEvent(new Event('input',{bubbles:true})); }catch(ignore){}
try{ hit.select.dispatchEvent(new Event('change',{bubbles:true})); }catch(ignore){}
changed.nodes.push(hit.select);
changed.count++;
}
return changed;
}
var changed = {count:0,nodes:[]};
changed = selectWanted(p.get('__vbook_source'), changed);
changed = selectWanted(p.get('__vbook_category'), changed);
changed = selectWanted(p.get('__vbook_status'), changed);
changed = selectWanted(p.get('__vbook_sort'), changed);
if(!changed.count) return 'no-filter';
var form = null;
for(var i=changed.nodes.length-1;i>=0;i--){
if(changed.nodes[i] && changed.nodes[i].form){ form = changed.nodes[i].form; break; }
if(changed.nodes[i] && changed.nodes[i].closest){
form = changed.nodes[i].closest('form'); if(form) break;
}
}
if(form){
try{
if(typeof form.requestSubmit === 'function'){ form.requestSubmit(); return 'submitted-form'; }
var btn = form.querySelector('button[type=submit],input[type=submit],button');
if(btn){ btn.click(); return 'clicked-form'; }
form.submit(); return 'submitted-native';
}catch(ignore){}
}
var all = Array.prototype.slice.call(document.querySelectorAll('button,input[type=submit],a,[role=button]'));
for(var k=0;k<all.length;k++){
var tx = norm(all[k].innerText || all[k].value || all[k].textContent);
if(tx==='search' || tx==='tim' || tx==='loc' || tx.indexOf('search')>=0){
try{ all[k].click(); return 'clicked-global'; }catch(ignore){}
}
}
return 'changed-no-submit';
})()
]]
end
local function make_list_extract_script(route, page_no, page_size)
local r = js_quote(route)
return string.format([[
(function(){
var route=%s;
function clean(s){return String(s||'').replace(/\s+/g,' ').trim();}
function isStoryUrl(href){
try{
var u=new URL(href,location.href),p=u.pathname.split('/').filter(Boolean);
return p.length===4 && p[0]==='truyen' && /^\d+$/.test(p[2]) && !!p[3];
}catch(e){return false;}
}
function storyLinks(root){
root=root||document;
return Array.prototype.slice.call(root.querySelectorAll('a[href*="/truyen/"]')).filter(function(a){return isStoryUrl(a.href);});
}
function bestScope(){
var selectors=[
'#searchresult','#searchresults','#booklist','#book-list','#novellist','#novel-list',
'[id*=searchresult]','[class*=search-result]','[class*=search_result]',
'[class*=book-list]','[class*=book_list]','[class*=novel-list]','[class*=novel_list]','main'
];
var candidates=[];
for(var i=0;i<selectors.length;i++){
var nodes=[];try{nodes=Array.prototype.slice.call(document.querySelectorAll(selectors[i]));}catch(ignore){}
for(var j=0;j<nodes.length;j++){
var count=storyLinks(nodes[j]).length;
if(count>=1)candidates.push({node:nodes[j],count:count});
}
}
candidates.sort(function(a,b){return b.count-a.count;});
return candidates.length?candidates[0].node:document;
}
function titleFrom(a,box){
var node=null;
if(box){try{node=box.querySelector('h1,h2,h3,h4,h5,h6,[class*=title],a[title]');}catch(ignore){}}
var title=clean(node&&(node.getAttribute('title')||node.innerText||node.textContent));
if(!title)title=clean(a.getAttribute('title'));
if(!title)title=clean(a.innerText||a.textContent);
return title;
}
var scope=bestScope(),links=storyLinks(scope);
if(!links.length&&scope!==document)links=storyLinks(document);
var seen=Object.create(null),out=[],samples=[];
for(var i=0;i<links.length;i++){
var a=links[i],u;try{u=new URL(a.href,location.href);}catch(e){continue;}
if(!isStoryUrl(u.href))continue;
if(samples.length<12)samples.push(u.href);
var box=a.closest('article,li,.book,.novel,.item,.row,.card,[class*=book],[class*=novel],[class*=item]')||a.parentElement;
var name=titleFrom(a,box);
if(!name||name.length<2||name.length>360)continue;
u.hash='';u.search='';
var key=u.origin+u.pathname.replace(/\/+$/,'')+'/';
if(seen[key])continue;seen[key]=1;
var img=box&&box.querySelector?box.querySelector('img'):null;
var cover=img?String(img.currentSrc||img.src||img.getAttribute('data-src')||img.getAttribute('data-original')||''):'';
out.push({name:name,url:key,cover:cover});
}
var next='';
if(out.length>0){
try{
var base=new URL(route||location.href,location.href);
var p=Number(base.searchParams.get('p')||1);
if(!isFinite(p)||p<1)p=1;
base.searchParams.set('p',String(p+1));
base.searchParams.delete('__vbook_page');
next=base.href;
}catch(e){}
}
return JSON.stringify({items:out,next:next,total:out.length,scope:(scope===document?'document':'result-scope'),resolved:String(location.href||''),samples:samples});
})()
]], r)
end
local function make_search_extract_script(query, page_no, page_size)
return make_list_extract_script('', page_no, page_size)
end
local function make_content_extract_script()
return [[
(function(){
var main = document.getElementById('maincontent')
|| document.querySelector('[id^="cld-"]')
|| document.querySelector('#content-container .contentbox');
var raw = main ? String(main.innerText || main.textContent || '') : '';
var lines = raw.split(String.fromCharCode(10));
var kept = [];
for(var i=0;i<lines.length;i++){
var t = String(lines[i] || '').trim();
if(!t) continue;
var l = t.toLowerCase();
if(l.indexOf('nhấp vào để tải chương') >= 0) continue;
if(l.indexOf('nhap vao de tai chuong') >= 0) continue;
if(l.indexOf('click to load') >= 0) continue;
kept.push(t);
}
var text = kept.join(String.fromCharCode(10) + String.fromCharCode(10)).trim();
var titleNode = document.getElementById('bookchapnameholder');
var title = titleNode ? String(titleNode.innerText || titleNode.textContent || '').trim() : '';
if(!title || title === '_'){
var cid = main ? String(main.getAttribute('cid') || '').trim() : '';
title = cid ? ('Chương ' + cid) : 'Chương truyện';
}
var prevNode = document.getElementById('navprevtop') || document.getElementById('navprevbot');
var nextNode = document.getElementById('navnexttop') || document.getElementById('navnextbot');
window.__VBOOK_STV_CONTENT_RESULT = {
title: title,
content: text,
prev: prevNode && prevNode.href ? prevNode.href : 'NO_PREV',
next: nextNode && nextNode.href ? nextNode.href : 'NO_NEXT'
};
return text;
})()
]]
end
local function make_exact_load_target_script()
return [[
(function(){
function clean(s){ return String(s||'').replace(/\s+/g,' ').trim(); }
function low(s){ return clean(s).toLowerCase(); }
function visible(el){
if(!el || !el.getBoundingClientRect) return false;
var st; try{st=getComputedStyle(el);}catch(e){return false;}
if(!st || st.display==='none' || st.visibility==='hidden' || Number(st.opacity)===0) return false;
var r=el.getBoundingClientRect();
return r.width>2 && r.height>2;
}
function isPrompt(text){
var t=low(text);
return t.indexOf('nhấp vào để tải chương')>=0
|| t.indexOf('nhap vao de tai chuong')>=0
|| t.indexOf('click to load')>=0;
}
function save(k,v){try{sessionStorage.setItem(k,String(v==null?'':v));}catch(e){}}
// v50: 4005 là tín hiệu mồi hữu ích nhưng không cần người dùng bấm XÁC NHẬN.
// Chỉ nuốt riêng alert chứa 4005; mọi alert khác vẫn đi qua handler gốc.
try{
if(!window.__VBOOK_STV_ALERT_4005_PATCHED){
window.__VBOOK_STV_ALERT_4005_PATCHED=true;
var originalAlert=window.alert;
window.alert=function(message){
var msg=String(message==null?'':message);
save('__VBOOK_STV_LAST_ALERT',msg);
if(msg.indexOf('4005')>=0) return undefined;
try{return originalAlert.apply(window,arguments);}catch(e){return undefined;}
};
}
}catch(ignoreAlertPatch){}
// Gắn đầu dò vào đúng XHR do website tạo. Không thay đổi header/body.
// sessionStorage sống qua reload cùng tab nên vẫn đọc được dấu vết sau 4005/reload.
try{
var xhr=window.chapterfetcher;
if(xhr && !xhr.__VBOOK_STV_PROBED){
xhr.__VBOOK_STV_PROBED=true;
try{
var originalSend=xhr.send;
xhr.send=function(body){
var payload=body==null?'':String(body);
save('__VBOOK_STV_LAST_BODY',payload);
save('__VBOOK_STV_LAST_SEND_AT',Date.now());
return originalSend.call(this,body);
};
}catch(ignoreSend){}
try{
xhr.addEventListener('loadend',function(){
save('__VBOOK_STV_LAST_STATUS',String(xhr.status||0));
save('__VBOOK_STV_LAST_RESPONSE',String(xhr.responseText||'').slice(0,1600));
save('__VBOOK_STV_LAST_DONE_AT',Date.now());
});
}catch(ignoreEvent){}
}
}catch(ignoreProbe){}
var olds=document.querySelectorAll('[data-vbook-stv-load-target="1"]');
for(var oi=0;oi<olds.length;oi++) olds[oi].removeAttribute('data-vbook-stv-load-target');
var main=document.querySelector('#content-container [id^="cld-"]')
|| document.getElementById('maincontent');
var ready=String(document.readyState||'');
if(!main) return 'missing:ready='+ready;
var text=clean(main.innerText||main.textContent||'');
var l=low(text);
var loading=l.indexOf('đang tải nội dung chương')>=0 || l.indexOf('dang tai noi dung chuong')>=0;
if(!isPrompt(text) && !loading && text.length>=180) return 'loaded:'+String(main.id||'')+':'+text.length+':ready='+ready;
if(loading) return 'loading:'+String(main.id||'')+':'+text.length+':ready='+ready;
var candidates=[];
var preferred=main.querySelectorAll('center,button,a,[role="button"],[onclick],div,span');
for(var i=0;i<preferred.length;i++){
var el=preferred[i];
if(!visible(el)||!isPrompt(el.innerText||el.textContent||'')) continue;
var r=el.getBoundingClientRect();
candidates.push({el:el,area:r.width*r.height,len:clean(el.innerText||el.textContent||'').length});
}
if(isPrompt(text)&&visible(main)){
var mr=main.getBoundingClientRect();
candidates.push({el:main,area:mr.width*mr.height,len:text.length});
}
if(!candidates.length) return 'other:'+String(main.id||'')+':'+text.length+':ready='+ready;
candidates.sort(function(a,b){if(a.len!==b.len)return a.len-b.len;return a.area-b.area;});
var target=candidates[0].el;
target.setAttribute('data-vbook-stv-load-target','1');
try{target.scrollIntoView({block:'center',inline:'center'});}catch(ignoreScroll){}
var rr=target.getBoundingClientRect();
return 'ready:'+String(target.tagName||'').toLowerCase()
+':text='+clean(target.innerText||target.textContent||'').slice(0,80)
+':x='+Math.round(rr.left+rr.width/2)
+':y='+Math.round(rr.top+rr.height/2)
+':doc='+ready;
})()
]]
end
local function normalize_story_url(value)
local s = tostring(value or "")
s = s:gsub("#.*$", "")
s = s:gsub("%?.*$", "")
if s:match("^https?://[^/]+/truyen/") then
s = s:gsub("/+$", "") .. "/"
end
return s
end
local function stv_build_chapter_api(story_url)
local url = normalize_story_url(story_url)
local source_key, book_id = url:match("/truyen/([^/]+)/[^/]+/([^/?#]+)/?")
if not source_key or not book_id then
return {url = "", source = "", bookid = "", story = url, story_prefix = ""}
end
local api = "https://sangtacviet.com/index.php?ngmar=chapterlist&h="
.. source_key .. "&bookid=" .. book_id .. "&sajax=getchapterlist"
local prefix = "/truyen/" .. source_key .. "/1/" .. book_id .. "/"
return {url = api, source = source_key, bookid = book_id, story = url, story_prefix = prefix}
end
local function stv_build_content_api(chapter_url)
local url = normalize_story_url(chapter_url)
local source_key, book_id, chapter_id = url:match("/truyen/([^/]+)/[^/]+/([^/?#]+)/([^/?#]+)/?")
if not source_key or not book_id or not chapter_id then
return {url = "", source = "", bookid = "", chapterid = "", referer = url, prefix = ""}
end
local api = "https://sangtacviet.com/index.php?bookid=" .. book_id
.. "&h=" .. source_key
.. "&c=" .. chapter_id
.. "&ngmar=readc&sajax=readchapter&sty=1&exts="
local prefix = "https://sangtacviet.com/truyen/" .. source_key .. "/1/" .. book_id .. "/"
return {
url = api,
source = source_key,
bookid = book_id,
chapterid = chapter_id,
referer = url,
prefix = prefix
}
end
local function stv_build_nav_url(value, prefix, empty_value)
local id = tostring(value or "")
id = id:match("^%s*(.-)%s*$") or ""
if id == "" or id == "0" or id == "nil" then
return empty_value or ""
end
return tostring(prefix or "") .. id .. "/"
end
local function stv_page_window(page_value, story_url)
local p = 1
local size = 100000
local start_index = 0
local end_index = size
return {page = p, start_index = start_index, end_index = end_index, probe_end = end_index, next_url = ""}
end
return {
api_version = 2,
metadata = {
id = "sangtacviet-native-instant-fast-v50",
name = "Sáng Tác Việt",
version = 51,
author = "Nghe Truyện",
website = "https://sangtacviet.com",
description = "Nguồn đọc truyện Sáng Tác Việt, sửa mục lục đầy đủ và xuống dòng phần giới thiệu.",
locale = "vi",
type = "novel",
updated = "2026-07-23"
},
source = {
base_url = "https://sangtacviet.com",
home_url = "https://sangtacviet.com/",
allowed_hosts = {
"sangtacviet.app", "www.sangtacviet.app",
"sangtacviet.com", "www.sangtacviet.com",
"sangtacviet.vip", "www.sangtacviet.vip",
"sangtacviet.xyz", "www.sangtacviet.xyz",
"sangtacvietcdn.xyz", "staticvn.sangtacvietcdn.xyz"
},
permissions = {
browser = true,
storage = false,
hosts = {
"sangtacviet.app", "www.sangtacviet.app",
"sangtacviet.com", "www.sangtacviet.com",
"sangtacviet.vip", "www.sangtacviet.vip",
"sangtacviet.xyz", "www.sangtacviet.xyz",
"sangtacvietcdn.xyz", "staticvn.sangtacvietcdn.xyz"
}
},
config = {
timeout = {title = "Thời gian chờ", ["default"] = "30000", mode = "input", format = "number"}
},
pipelines = {
normalize_stories = {
steps = {
{transform = {from = "$args.items", operations = {
{op = "filter", as = "item", condition = {left = "$vars.item.url", op = "not_empty"}},
{op = "filter", as = "item", condition = {left = "$vars.item.name", op = "not_empty"}},
{op = "filter", as = "item", condition = {left = "$vars.item.url", op = "contains", right = "/truyen/"}},
{op = "unique", by = "url"}
}, into = "normalized"}}
}
},
},
hooks = {
stv_apply_filters_script = function(ctx, value)
return make_apply_filters_script(value)
end,
stv_list_extract_script = function(ctx, value, args)
return make_list_extract_script(value, args and args.page, args and args.size)
end,
stv_search_extract_script = function(ctx, value, args)
return make_search_extract_script(value, args and args.page, args and args.size)
end,
stv_content_extract_script = function()
return make_content_extract_script()
end,
stv_exact_load_target_script = function()
return make_exact_load_target_script()
end,
stv_normalize_story_url = function(ctx, value)
return normalize_story_url(value)
end,
stv_build_chapter_api = function(ctx, value)
return stv_build_chapter_api(value)
end,
stv_build_content_api = function(ctx, value)
return stv_build_content_api(value)
end,
stv_build_nav_url = function(ctx, value, args)
return stv_build_nav_url(value, args and args.prefix, args and args.empty_value)
end,
stv_page_window = function(ctx, value, args)
return stv_page_window(value, args and args.story_url)
end,
},
actions = {
categories = {
result = {type = "categories", items = {
{name = "Mới cập nhật", url = "https://sangtacviet.com/search/?find=&minc=0&sort=update&tag="},
{name = "Xem nhiều tuần", url = "https://sangtacviet.com/search/?find=&minc=0&tag=&__vbook_sort=Lượt xem tuần"},
{name = "Hoàn thành", url = "https://sangtacviet.com/search/?find=&minc=0&step=3&tag="},
{name = "Huyền huyễn", url = "https://sangtacviet.com/search/?find=&minc=0&category=hh&tag="},
{name = "Đô thị", url = "https://sangtacviet.com/search/?find=&minc=0&category=dt&tag="},
{name = "Ngôn tình", url = "https://sangtacviet.com/search/?find=&minc=0&category=nt&tag="},
{name = "Đồng nhân", url = "https://sangtacviet.com/search/?find=&minc=0&category=dn&tag="},
{name = "Khoa học viễn tưởng", url = "https://sangtacviet.com/search/?find=&minc=0&category=khvt&tag="}
}, fields = {name = "name", url = {path = "url", absolute = true}}}
},
latest = {
steps = {
{set = {target = {first = {{from = "$page"}, {value = "https://sangtacviet.com/"}}}}},
{request = {id = "list", url = "{vars.target}", response = "html", timeout = "{config.timeout??40000}", retries = 1}},
{set = {
raw_items = {from = "$list", items = {selector = "a[href*='/truyen/']"}, fields = {
name = {self = true},
url = {self = true, attr = "href", absolute = true},
cover = {selector = "img", attr = "src", absolute = true}
}}
}},
{call_pipeline = {name = "normalize_stories", args = {items = "$vars.raw_items"}, into = "items"}}
},
result = {type = "items", from = "$vars.items", allow_empty = true, fields = {name = "name", url = {path = "url", absolute = true}, cover = {path = "cover", absolute = true}}}
},
stories = {
steps = {
{set = {
target = {first = {{from = "$page"}, {from = "$input"}, {value = "https://sangtacviet.com/search/?find=&minc=0&tag="}}}
}},
{browser = {op = "launch_async", session = "list", url = "{vars.target}", block = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".woff", ".woff2", "byteimg.com/novel-pic", "static.sangtacvietcdn.xyz/img/"}, wait_selector = {"a[href*='/truyen/']"}, wait_timeout = 12000, allow_wait_timeout = true}},
{hook = {name = "stv_apply_filters_script", input = "$vars.target", context = false, into = "category_filter_script"}},
{browser = {op = "evaluate", session = "list", script = "{vars.category_filter_script}", response = "text", into = "category_filter_result"}, on_error = "continue"},
{browser = {op = "wait_selector", session = "list", selectors = {"a[href*='/truyen/']"}, timeout = 8000, allow_timeout = true, into = "category_filter_wait"}},
{hook = {name = "stv_list_extract_script", input = "$vars.target", args = {page = 1, size = 0}, context = false, into = "list_script"}},
{browser = {op = "evaluate", session = "list", script = "{vars.list_script}", response = "json", into = "list_data"}},
{log = "STV_LIST_V23 total={vars.list_data.total} resolved={vars.list_data.resolved} next={vars.list_data.next} samples={vars.list_data.samples}"}
},
result = {type = "items", from = "$vars.list_data.items", allow_empty = true, fields = {name = "name", url = {path = "url", absolute = true}, cover = {path = "cover", absolute = true}}, next = {from = "$vars.list_data.next"}}
},
search = {
steps = {
{set = {
target = {first = {{from = "$page"}, {template = "https://sangtacviet.com/search/?find=&findinname={query|urlencode}&minc=0&tag="}}}
}},
{browser = {op = "launch_async", session = "search", url = "{vars.target}", block = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".woff", ".woff2", "byteimg.com/novel-pic", "static.sangtacvietcdn.xyz/img/"}, wait_selector = {"a[href*='/truyen/']"}, wait_timeout = 12000, allow_wait_timeout = true}},
{hook = {name = "stv_search_extract_script", input = "$query", args = {page = 1, size = 0}, context = false, into = "search_script"}},
{browser = {op = "evaluate", session = "search", script = "{vars.search_script}", response = "json", into = "list_data"}},
{log = "STV_SEARCH_V23 query={query} total={vars.list_data.total} resolved={vars.list_data.resolved} next={vars.list_data.next}"}
},
result = {type = "items", from = "$vars.list_data.items", allow_empty = true, fields = {name = "name", url = {path = "url", absolute = true}, cover = {path = "cover", absolute = true}}, next = {from = "$vars.list_data.next"}}
},
detail = {
steps = {
{hook = {name = "stv_normalize_story_url", input = "$input", context = false, into = "target"}},
{request = {id = "detail_text", url = "{vars.target}", response = "text", timeout = "{config.timeout??40000}", retries = 1}},
{set = {
detail_doc = {from = "$detail_text", parse = "html"}
}},
{transform = {from = "$detail_text", operations = {
{op = "regex_replace", pattern = "<script[\\s\\S]*?</script>", flags = "gi", replacement = ""},
{op = "regex_replace", pattern = "<style[\\s\\S]*?</style>", flags = "gi", replacement = ""},
{op = "regex_replace", pattern = "<br\\s*/?>", flags = "gi", replacement = "\n"},
{op = "regex_replace", pattern = "</(?:p|div|li|section|article|h[1-6]|header|footer|main|aside|table|tr|td|th|span|b|strong)>", flags = "gi", replacement = "\n"},
{op = "regex_replace", pattern = "<[^>]+>", flags = "g", replacement = ""},
{op = "html_decode"},
{op = "regex_replace", pattern = "\\r", flags = "g", replacement = ""},
{op = "regex_replace", pattern = "[ \\t]+", flags = "g", replacement = " "},
{op = "regex_replace", pattern = "\\n[ \\t]+", flags = "g", replacement = "\n"},
{op = "regex_replace", pattern = "\\n\\s*\\n\\s*\\n+", flags = "g", replacement = "\n\n"},
{op = "trim"}
}, into = "detail_plain"}},
{set = {
summary_raw = {first = {
{from = "$vars.detail_plain", regex = "(?:Tóm tắt|Tom tat|Summary)\\s*([\\s\\S]{1,30000}?)\\s*(?=(?:Thông tin|Thong tin|Info)\\b)", flags = "i", group = 1},
{from = "$detail_text", regex = "(?:Tóm tắt|Tom tat|Summary)[\\s\\S]{0,300}?</[^>]+>([\\s\\S]{1,30000}?)(?=<[^>]+>\\s*(?:Thông tin|Thong tin|Info)\\s*</[^>]+>)", flags = "i", group = 1}
}}
}},
{transform = {from = "$vars.summary_raw", operations = {
{op = "regex_replace", pattern = "<script[\\s\\S]*?</script>", flags = "gi", replacement = ""},
{op = "regex_replace", pattern = "<style[\\s\\S]*?</style>", flags = "gi", replacement = ""},
{op = "regex_replace", pattern = "<br\\s*/?>", flags = "gi", replacement = "\n"},
{op = "regex_replace", pattern = "</(?:p|div|li|section|article|h[1-6])>", flags = "gi", replacement = "\n"},
{op = "regex_replace", pattern = "<[^>]+>", flags = "g", replacement = ""},
{op = "html_decode"},
{op = "regex_replace", pattern = "\\\\r\\\\n", flags = "g", replacement = "\n"},
{op = "regex_replace", pattern = "\\\\n", flags = "g", replacement = "\n"},
{op = "regex_replace", pattern = "\\\\r", flags = "g", replacement = "\n"},
{op = "regex_replace", pattern = "\\\\t", flags = "g", replacement = " "},
{op = "regex_replace", pattern = "[ \\t]+", flags = "g", replacement = " "},
{op = "regex_replace", pattern = "\\n\\s*\\n\\s*\\n+", flags = "g", replacement = "\n\n"},
{op = "trim"}
}, into = "summary_clean"}}
},
result = {type = "detail", from = "$vars.detail_doc", fields = {
name = {selector = "meta[property='og:title']", attr = "content"},
author = {selector = "meta[property='og:novel:author']", attr = "content"},
cover = {selector = "meta[property='og:image']", attr = "content", absolute = true},
description = {first = {
{from = "$vars.summary_clean"},
{selector = "*:matchesOwn((?i)^\\s*(?:Tóm tắt|Summary)\\s*$) + *"},
{selector = {"#booksummary", "#bookdesc", "#description", "[id*=summary]", "[class*=book-summary]", "[class*=book-description]"}},
{selector = "meta[property='og:description']", attr = "content"}
}},
ongoing = {selector = "meta[property='og:novel:status']", attr = "content", matches = "Còn tiếp|Ongoing|Đang ra|Đang cập nhật"},
genres = {selector = "meta[property='og:novel:category']", attr = "content"}
}}
},
chapters = {
steps = {
{set = {
raw_target = {first = {{from = "$page"}, {from = "$input"}}},
page_no = {from = "$page", regex = "[?&]__vbook_stv_toc=(\\d+)", group = 1, ["default"] = "1"}
}},
{hook = {name = "stv_normalize_story_url", input = "$vars.raw_target", context = false, into = "target"}},
{hook = {name = "stv_build_chapter_api", input = "$vars.target", context = false, into = "chapter_api"}},
{assert = {condition = {left = "$vars.chapter_api.url", op = "not_empty"}, message = "Không nhận diện được mã nguồn/bookid từ URL truyện Sáng Tác Việt"}},
{hook = {name = "stv_page_window", input = "$vars.page_no", args = {story_url = "$vars.target"}, context = false, into = "window"}},
{request = {
id = "chapter_api",
url = "{vars.chapter_api.url}",
response = "json",
timeout = 18000,
retries = 1,
headers = {
["Referer"] = "{vars.target}",
["X-Requested-With"] = "XMLHttpRequest",
["Accept"] = "application/json,text/plain,*/*"
}
}},
{set = {
api_data = {from = "$chapter_api.data", ["default"] = ""}
}},
{transform = {from = "$vars.api_data", operations = {
{op = "substring", start = 0, length = 900}
}, into = "api_preview"}},
{transform = {from = "$vars.api_data", operations = {
{op = "split", separator = "-//-"},
{op = "map", as = "record", fields = {
name = {self = true, regex = "^[\\s\\S]*?-/-[\\s\\S]*?-/-\\s*([\\s\\S]*?)(?:-/-[\\s\\S]*)?$", group = 1},
url = {self = true, regex = "^[\\s\\S]*?-/-\\s*([^/]+?)\\s*-/-", group = 1, prefix = "{vars.chapter_api.story}", suffix = "/"}
}},
{op = "filter", as = "item", condition = {all = {
{left = "$vars.item.name", op = "not_empty"},
{left = "$vars.item.url", op = "not_empty"}
}}},
{op = "unique", by = "url"}
}, into = "all_chapters"}},
{log = "STV_TOC_API_V51_ALL source={vars.chapter_api.source} bookid={vars.chapter_api.bookid} preview={vars.api_preview}"}
},
result = {type = "items", from = "$vars.all_chapters", allow_empty = true, fields = {
name = "name", url = {path = "url", absolute = true}
}}
},
content = {
steps = {
{hook = {name = "stv_normalize_story_url", input = "$input", context = false, into = "target"}},
{hook = {name = "stv_build_content_api", input = "$vars.target", context = false, into = "content_api"}},
{assert = {condition = {left = "$vars.content_api.url", op = "not_empty"}, message = "Không nhận diện được source/bookid/chapterid từ URL chương Sáng Tác Việt"}},
{request = {
id = "chapter_read_instant_v50",
url = "{vars.content_api.url}",
method = "POST",
body = "",
response = "json",
timeout = 9000,
retries = 0,
headers = {
["Content-Type"] = "application/x-www-form-urlencoded",
["Referer"] = "{vars.content_api.referer}",
["Origin"] = "https://sangtacviet.com",
["Accept"] = "*/*"
}
}},
{set = {
instant_code = {from = "$chapter_read_instant_v50.code", ["default"] = -1},
instant_error = {first = {{from = "$chapter_read_instant_v50.err"}, {from = "$chapter_read_instant_v50.info"}, {value = ""}}},
native_code = {from = "$chapter_read_instant_v50.code", ["default"] = -1},
native_error = {first = {{from = "$chapter_read_instant_v50.err"}, {from = "$chapter_read_instant_v50.info"}, {value = ""}}},
native_content = {from = "$chapter_read_instant_v50.data", ["default"] = ""},
native_title = {from = "$chapter_read_instant_v50.chaptername", ["default"] = ""},
native_prev = {from = "$chapter_read_instant_v50.prev", ["default"] = "0"},
native_next = {from = "$chapter_read_instant_v50.next", ["default"] = "0"},
browser_content = {value = ""},
browser_title = {value = ""},
browser_opened = {value = "0"},
prime_phase = {value = "SKIP"},
prime_tap = {value = "SKIP"},
fast_mode = {value = "instant-native"}
}},
{if_ = {condition = {left = "$vars.native_content", op = "equals", right = ""}, then_steps = {
{set = {fast_mode = {value = "browser-handshake"}}},
{browser = {op = "block", session = "chapter", urls = {
".jpg", ".jpeg", ".png", ".webp", ".gif", ".woff", ".woff2", "byteimg.com/novel-pic"
}}},
{browser = {op = "launch", session = "chapter", url = "{vars.target}", timeout = 17000}},
{set = {browser_opened = {value = "1"}}},
{browser = {op = "evaluate", session = "chapter",
script = "String(navigator.userAgent||'')",
response = "text", timeout = 5000, into = "browser_ua"}, on_error = "continue"},
{request = {
id = "chapter_read_after_browser_v50",
url = "{vars.content_api.url}",
method = "POST",
body = "",
response = "json",
timeout = 10000,
retries = 0,
headers = {
["Content-Type"] = "application/x-www-form-urlencoded",
["Referer"] = "{vars.content_api.referer}",
["Origin"] = "https://sangtacviet.com",
["Accept"] = "*/*",
["User-Agent"] = "{vars.browser_ua}"
}
}},
{set = {
native_code = {from = "$chapter_read_after_browser_v50.code", ["default"] = -1},
native_error = {first = {{from = "$chapter_read_after_browser_v50.err"}, {from = "$chapter_read_after_browser_v50.info"}, {value = ""}}},
native_content = {from = "$chapter_read_after_browser_v50.data", ["default"] = ""},
native_title = {from = "$chapter_read_after_browser_v50.chaptername", ["default"] = ""},
native_prev = {from = "$chapter_read_after_browser_v50.prev", ["default"] = "0"},
native_next = {from = "$chapter_read_after_browser_v50.next", ["default"] = "0"}
}},
{if_ = {condition = {left = "$vars.native_content", op = "equals", right = ""}, then_steps = {
{hook = {name = "stv_exact_load_target_script", input = "", context = false, into = "prepare_script_v50"}},
{browser = {op = "evaluate", session = "chapter", script = "{vars.prepare_script_v50}", response = "text", timeout = 6000, into = "prime_phase"}, on_error = "continue"},
{if_ = {condition = {left = "$vars.prime_phase", op = "starts_with", right = "ready:"}, then_steps = {
{browser = {op = "tap_selector", session = "chapter", selector = "[data-vbook-stv-load-target='1']", timeout = 5000, into = "prime_tap"}, on_error = "continue"},
{sleep = 350}
}}},
{request = {
id = "chapter_read_after_prime_v50",
url = "{vars.content_api.url}",
method = "POST",
body = "",
response = "json",
timeout = 10000,
retries = 0,
headers = {
["Content-Type"] = "application/x-www-form-urlencoded",
["Referer"] = "{vars.content_api.referer}",
["Origin"] = "https://sangtacviet.com",
["Accept"] = "*/*",
["User-Agent"] = "{vars.browser_ua}"
}
}},
{set = {
native_code = {from = "$chapter_read_after_prime_v50.code", ["default"] = -1},
native_error = {first = {{from = "$chapter_read_after_prime_v50.err"}, {from = "$chapter_read_after_prime_v50.info"}, {value = ""}}},
native_content = {from = "$chapter_read_after_prime_v50.data", ["default"] = ""},
native_title = {from = "$chapter_read_after_prime_v50.chaptername", ["default"] = ""},
native_prev = {from = "$chapter_read_after_prime_v50.prev", ["default"] = "0"},
native_next = {from = "$chapter_read_after_prime_v50.next", ["default"] = "0"}
}}
}}},
{hook = {name = "stv_content_extract_script", input = "", context = false, into = "content_script_v50"}},
{browser = {op = "evaluate", session = "chapter", script = "{vars.content_script_v50}", response = "text", timeout = 5000, into = "browser_content"}, on_error = "continue"},
{browser = {op = "evaluate", session = "chapter",
script = "String(document.getElementById('bookchapnameholder')?document.getElementById('bookchapnameholder').innerText:'')",
response = "text", timeout = 5000, into = "browser_title"}, on_error = "continue"}
}}},
{hook = {name = "stv_build_nav_url", input = "$vars.native_prev", args = {prefix = "$vars.content_api.prefix", empty_value = ""}, context = false, into = "native_prev_url"}},
{hook = {name = "stv_build_nav_url", input = "$vars.native_next", args = {prefix = "$vars.content_api.prefix", empty_value = ""}, context = false, into = "native_next_url"}},
{set = {
final_content = {first = {{from = "$vars.native_content"}, {from = "$vars.browser_content"}}},
final_title = {first = {{from = "$vars.native_title"}, {from = "$vars.browser_title"}, {value = "Chương truyện"}}},
prev_url = {first = {{from = "$vars.native_prev_url"}, {value = "NO_PREV"}}},
next_url = {first = {{from = "$vars.native_next_url"}, {value = "NO_NEXT"}}}
}},
{if_ = {condition = {left = "$vars.final_content", op = "equals", right = ""}, then_steps = {
{set = {
final_title = {value = "⚡ Đã mồi phiên 4005 - mở lại chương"},
final_content = {template = "Đã kích hoạt bước mồi trên chính trang chương. Instant code={vars.instant_code}; code cuối={vars.native_code}.\n\nPrime phase: {vars.prime_phase}\nPrime tap: {vars.prime_tap}\n\nHộp thoại 4005 đã được ẩn ở tầng nguồn. Hãy mở lại chương này một lần; không cần RESET."},
prev_url = {value = "NO_PREV"},
next_url = {value = "NO_NEXT"}
}}
}}},
{if_ = {condition = {left = "$vars.browser_opened", op = "equals", right = "1"}, then_steps = {
{browser = {op = "close", session = "chapter"}}
}}},
{log = "STV_CONTENT_V50_INSTANT fastMode={vars.fast_mode} instantCode={vars.instant_code} finalCode={vars.native_code} primePhase={vars.prime_phase} primeTap={vars.prime_tap} title={vars.final_title}"}
},
result = {type = "content", fields = {
title = {from = "$vars.final_title", ["default"] = "Chương truyện"},
content = {from = "$vars.final_content"},
prev = {from = "$vars.prev_url", ["default"] = "NO_PREV"},
next = {from = "$vars.next_url", ["default"] = "NO_NEXT"}
}}
}
}
}
}