return {
  api_version = 2,

  metadata = {
    id = "truyencv-io-default-native",
    name = "TCV",
    version = 8,
    author = "Nghe Truyện",
    website = "https://truyencv.io",
    description = "Nguồn TCV tích hợp, tải nhanh trang truyện và trang mục lục chứa Chương 1; các trang tiếp theo được tải khi người dùng cuộn, theo thứ tự từ cũ đến mới.",
    locale = "vi",
    type = "novel",
    updated = "2026-07-21"
  },

  source = {
    base_url = "https://truyencv.io",
    home_url = "https://truyencv.io/moi-cap-nhat/",
    allowed_hosts = {"truyencv.io", "www.truyencv.io"},

    permissions = {
      browser = false,
      network_capture = false,
      storage = false,
      hosts = {"truyencv.io", "www.truyencv.io"}
    },

    config = {
      timeout = {
        title = "Thời gian chờ",
        ["default"] = "30000",
        mode = "input",
        format = "number"
      }
    },

    pipelines = {
      normalize_items = {
        steps = {
          {
            transform = {
              from = "$args.items",
              operations = {
                {op = "filter", as = "item", condition = {left = "$vars.item.url", op = "not_empty"}},
                {op = "filter", as = "item", condition = {left = "$vars.item.name", op = "not_empty"}},
                {op = "unique", by = "url"}
              },
              into = "normalized"
            }
          }
        }
      },

      normalize_chapters = {
        steps = {
          {
            transform = {
              from = "$args.items",
              operations = {
                {op = "filter", as = "item", condition = {left = "$vars.item.url", op = "not_empty"}},
                {op = "filter", as = "item", condition = {left = "$vars.item.name", op = "contains", right = "Chương"}},
                {op = "unique", by = "url"},
                {op = "reverse"}
              },
              into = "normalized"
            }
          }
        }
      },


    },

    hooks = {
      normalize_story_base = function(ctx, value)
        local base = tostring(value or ctx.input or "")
        base = base:gsub("#.*$", "")
        base = base:gsub("/chuong/page/%d+/?$", "")
        base = base:gsub("/+$", "")
        return base .. "/"
      end,

      max_chapter_page = function(ctx, value)
        local max_page = 1
        if type(value) == "table" then
          for _, href in ipairs(value) do
            local n = tonumber(tostring(href or ""):match("/chuong/page/(%d+)/"))
            if n and n > max_page then max_page = n end
          end
        else
          local n = tonumber(tostring(value or ""):match("/chuong/page/(%d+)/"))
          if n and n > max_page then max_page = n end
        end
        return max_page
      end,

      chapter_page_next = function(ctx, value)
        local url = tostring(value or ""):gsub("#.*$", "")
        local page = tonumber(url:match("/chuong/page/(%d+)/?$") or "")
        if not page or page <= 1 then return "" end
        return (url:gsub("/chuong/page/%d+/?$", "/chuong/page/" .. tostring(page - 1) .. "/"))
      end
    },

    actions = {
      categories = {
        result = {
          type = "categories",
          items = {
            {name = "Mới cập nhật", url = "https://truyencv.io/moi-cap-nhat/"},
            {name = "Truyện hay", url = "https://truyencv.io/the-loai/hay/"},
            {name = "Huyền Huyễn", url = "https://truyencv.io/the-loai/huyen-huyen/"},
            {name = "Hệ Thống", url = "https://truyencv.io/the-loai/he-thong/"},
            {name = "Đô Thị", url = "https://truyencv.io/the-loai/do-thi/"},
            {name = "Xuyên Không", url = "https://truyencv.io/the-loai/xuyen-khong/"},
            {name = "Tiên Hiệp", url = "https://truyencv.io/the-loai/tien-hiep/"},
            {name = "Ngôn Tình", url = "https://truyencv.io/the-loai/ngon-tinh/"},
            {name = "Đồng Nhân", url = "https://truyencv.io/the-loai/dong-nhan/"},
            {name = "Dị Năng", url = "https://truyencv.io/the-loai/di-nang/"},
            {name = "Hậu Cung", url = "https://truyencv.io/the-loai/hau-cung/"},
            {name = "Dị Giới", url = "https://truyencv.io/the-loai/di-gioi/"}
          },
          fields = {
            name = "name",
            url = {path = "url", absolute = true}
          }
        }
      },

      latest = {
        steps = {
          {set = {target = {first = {{from = "$page"}, {value = "https://truyencv.io/moi-cap-nhat/"}}}}},
          {
            request = {
              id = "latest_page",
              url = "{vars.target}",
              response = "html",
              timeout = "{config.timeout??30000}",
              retries = 1
            }
          },
          {
            set = {
              raw_items = {
                from = "$latest_page",
                items = {
                  selector = "h1 a[href*='/truyen/'], h2 a[href*='/truyen/'], h3 a[href*='/truyen/'], h4 a[href*='/truyen/'], .post-title a[href*='/truyen/'], .manga-title a[href*='/truyen/'], .item-title a[href*='/truyen/']"
                },
                fields = {
                  name = {self = true},
                  url = {self = true, attr = "href", absolute = true}
                }
              },
              next_page = {
                from = "$latest_page",
                selector = {"a[rel=next]", ".pagination a.next", ".pagination .next a", ".nav-links a.next"},
                attr = "href",
                absolute = true
              }
            }
          },
          {call_pipeline = {name = "normalize_items", args = {items = "$vars.raw_items"}, into = "items"}}
        },
        result = {
          type = "items",
          from = "$vars.items",
          fields = {
            name = "name",
            url = {path = "url", absolute = true}
          },
          next = {from = "$vars.next_page"}
        }
      },

      stories = {
        steps = {
          {set = {target = {first = {{from = "$page"}, {from = "$input"}, {value = "https://truyencv.io/moi-cap-nhat/"}}}}},
          {
            request = {
              id = "stories_page",
              url = "{vars.target}",
              response = "html",
              timeout = "{config.timeout??30000}",
              retries = 1
            }
          },
          {
            set = {
              raw_items = {
                from = "$stories_page",
                items = {
                  selector = "h1 a[href*='/truyen/'], h2 a[href*='/truyen/'], h3 a[href*='/truyen/'], h4 a[href*='/truyen/'], .post-title a[href*='/truyen/'], .manga-title a[href*='/truyen/'], .item-title a[href*='/truyen/']"
                },
                fields = {
                  name = {self = true},
                  url = {self = true, attr = "href", absolute = true}
                }
              },
              next_page = {
                from = "$stories_page",
                selector = {"a[rel=next]", ".pagination a.next", ".pagination .next a", ".nav-links a.next"},
                attr = "href",
                absolute = true
              }
            }
          },
          {call_pipeline = {name = "normalize_items", args = {items = "$vars.raw_items"}, into = "items"}}
        },
        result = {
          type = "items",
          from = "$vars.items",
          fields = {
            name = "name",
            url = {path = "url", absolute = true}
          },
          next = {from = "$vars.next_page"}
        }
      },

      search = {
        steps = {
          {set = {target = {template = "https://truyencv.io/?s={query|urlencode}"}}},
          {["when"] = {from = "$page"}, set = {target = {from = "$page"}}},
          {
            request = {
              id = "search_page",
              url = "{vars.target}",
              response = "html",
              timeout = "{config.timeout??30000}",
              retries = 1
            }
          },
          {
            set = {
              raw_items = {
                from = "$search_page",
                items = {
                  selector = "h1 a[href*='/truyen/'], h2 a[href*='/truyen/'], h3 a[href*='/truyen/'], h4 a[href*='/truyen/'], .post-title a[href*='/truyen/'], .manga-title a[href*='/truyen/'], .item-title a[href*='/truyen/']"
                },
                fields = {
                  name = {self = true},
                  url = {self = true, attr = "href", absolute = true}
                }
              },
              next_page = {
                from = "$search_page",
                selector = {"a[rel=next]", ".pagination a.next", ".pagination .next a", ".nav-links a.next"},
                attr = "href",
                absolute = true
              }
            }
          },
          {call_pipeline = {name = "normalize_items", args = {items = "$vars.raw_items"}, into = "items"}}
        },
        result = {
          type = "items",
          from = "$vars.items",
          allow_empty = true,
          fields = {
            name = "name",
            url = {path = "url", absolute = true}
          },
          next = {from = "$vars.next_page"}
        }
      },

      detail = {
        request = {
          id = "detail",
          url = "{input}",
          response = "html",
          timeout = "{config.timeout??30000}",
          retries = 1
        },
        result = {
          type = "detail",
          from = "$detail",
          fields = {
            name = {selector = "h1"},
            author = {
              selector = {"a[href*='/tac-gia/']", "a[href*='/author/']"}
            },
            cover = {
              selector = {"meta[property=og:image]", ".summary_image img", ".book img", ".profile-manga img", "img.wp-post-image"},
              attr = "content",
              absolute = true
            },
            description = {
              selector = {".summary__content", ".description-summary", ".manga-excerpt", ".summary-content", ".tab-summary .summary__content", "meta[name=description]"},
              mode = "html"
            },
            ongoing = {
              selector = "body",
              matches = "Đang tiến hành|Đang ra"
            },
            genres = {
              items = {selector = "a[href*='/the-loai/']"},
              fields = {
                name = {self = true},
                url = {self = true, attr = "href", absolute = true}
              }
            }
          }
        }
      },

      chapters = {
        steps = {
          {hook = {name = "normalize_story_base", input = "$input", context = false, into = "story_base"}},
          {set = {is_chapter_page = {from = "$input", contains = "/chuong/page/"}}},
          {
            if_ = {
              condition = {left = "$vars.is_chapter_page", op = "equals", right = true},
              then_steps = {
                {
                  request = {
                    id = "chapter_page",
                    url = "{input}",
                    response = "html",
                    timeout = "{config.timeout??30000}",
                    retries = 1
                  }
                }
              },
              else_steps = {
                {
                  request = {
                    id = "chapter_index",
                    url = "{vars.story_base}",
                    response = "html",
                    timeout = "{config.timeout??30000}",
                    retries = 1
                  }
                },
                {
                  set = {
                    pagination_urls = {
                      from = "$chapter_index",
                      selector = "a[href*='/chuong/page/']",
                      attr = "href",
                      all = true,
                      absolute = true
                    }
                  }
                },
                {hook = {name = "max_chapter_page", input = "$vars.pagination_urls", context = false, into = "page_count"}},
                {
                  request = {
                    id = "chapter_page",
                    url = "{vars.story_base}chuong/page/{vars.page_count}/",
                    response = "html",
                    timeout = "{config.timeout??30000}",
                    retries = 1
                  }
                }
              }
            }
          },
          {hook = {name = "chapter_page_next", input = "$url", context = false, into = "next_page"}},
          {
            set = {
              raw_chapters = {
                from = "$chapter_page",
                items = {
                  selector = "#chapter-list a[href*='/chuong-'], .chapter-list a[href*='/chuong-']"
                },
                fields = {
                  name = {self = true},
                  url = {self = true, attr = "href", absolute = true}
                }
              }
            }
          },
          {call_pipeline = {name = "normalize_chapters", args = {items = "$vars.raw_chapters"}, into = "chapter_items"}}
        },
        result = {
          type = "items",
          from = "$vars.chapter_items",
          fields = {
            name = "name",
            url = {path = "url", absolute = true}
          },
          next = {from = "$vars.next_page"}
        }
      },

      content = {
        request = {
          id = "chapter",
          url = "{input}",
          response = "html",
          timeout = "{config.timeout??30000}",
          retries = 1
        },
        result = {
          type = "content",
          from = "$chapter",
          fields = {
            title = {
              selector = {"h2", ".chapter-title", "title"}
            },
            content = {
              selector = {
                ".reading-content .text-left",
                ".chapter-content .text-left",
                ".chapter-content-inner",
                ".chapter-content",
                "#chapter-content",
                "#chapter-c",
                ".chapter-c",
                "[itemprop=articleBody]"
              },
              mode = "html",
              remove = {
                "script", "style", "iframe", "noscript", "form", "nav",
                ".ads", ".advertisement", ".chapter-nav", ".navigation",
                ".social-share", ".comments-area", "#comments", ".related",
                ".related-posts", ".c-selectpicker", ".selectpicker"
              }
            },
            prev = {
              selector = {"a.prev_page", "a[rel=prev]", ".chapter-nav a:first-child"},
              attr = "href",
              absolute = true
            },
            next = {
              selector = {"a.next_page", "a[rel=next]", ".chapter-nav a:last-child"},
              attr = "href",
              absolute = true
            }
          }
        }
      }
    }
  }
}
